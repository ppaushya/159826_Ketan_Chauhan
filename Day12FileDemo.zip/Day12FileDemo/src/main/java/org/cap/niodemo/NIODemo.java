package org.cap.niodemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;

public class NIODemo {

	public static void main(String[] args) {

		File src = new File("D:\\FileDemoJava\\sample.txt");
		File dest = new File("D:\\FileDemoJava\\sample55.txt");
		

		FileInputStream inputStream=null;
		FileOutputStream outputStream=null;
		try {
			inputStream = new FileInputStream(src);
			ReadableByteChannel readableIn = inputStream.getChannel();
			
			outputStream = new FileOutputStream(dest);
			WritableByteChannel writableOut = outputStream.getChannel();

			ByteBuffer buffer = ByteBuffer.allocate(10*1024);
			while (readableIn.read(buffer)!=-1) {
				buffer.flip();
				while (buffer.hasRemaining()) {
					writableOut.write(buffer);
				}
				buffer.clear();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

}
