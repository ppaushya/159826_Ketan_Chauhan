package org.cap.file;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferReaderDemo {

	public static void main(String[] args) {

		File file = new File("D:\\FileDemoJava\\sample.txt");
		
		try(FileInputStream inputStream = new FileInputStream(file);
			BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream)) 
			{
			/*int i;
			while((i = bufferedInputStream.read())!=-1) {
				System.out.print((char)i);
			}*/
			
			byte[] arr = new byte[1000];
			bufferedInputStream.read(arr);
			for(int i=0;i<arr.length;i++) {
				System.out.print((char)arr[i]);
			}
		} catch (IOException e) {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
			e.printStackTrace();
		}
	}

}
