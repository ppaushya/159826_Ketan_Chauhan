package org.cap.file;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class FormattedOutputDemo {

	public static void main(String[] args) {

		int id = 124;
		String ename = "Tom";
		double salary = 10000;
		boolean per = true;
		char gender = 'M';
		

		File file = new File("D:\\FileDemoJava\\sampleFromatted.txt");
		
		try(FileOutputStream fileOutputStream = new FileOutputStream(file);
			DataOutputStream dataOutputStream = new DataOutputStream(fileOutputStream)){
			
			dataOutputStream.writeInt(id);
			dataOutputStream.writeDouble(salary);
			dataOutputStream.writeBoolean(per);
			dataOutputStream.writeChar(gender);
			dataOutputStream.write(ename.getBytes());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
