package org.cap.file;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferWriterDemo {

	public static void main(String[] args) {

		File file = new File("D:\\FileDemoJava\\sampleWrite.txt");
		
		try(FileOutputStream fileOutputStream = new FileOutputStream(file);
			BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
			) {
			
			String str = "the quick brown fox jumps over the lazy dog!";
			byte[] arr = str.getBytes();
//			bufferedOutputStream.write(arr);
			bufferedOutputStream.write(arr,5,10);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
