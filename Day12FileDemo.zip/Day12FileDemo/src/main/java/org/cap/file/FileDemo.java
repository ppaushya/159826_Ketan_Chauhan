package org.cap.file;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		
		File file = new File("D:\\FileDemoJava\\mydemo.txt");
		
/*		if(file.exists()) {
			System.out.println("path "+file.getAbsolutePath());
			System.out.println("isDirectory "+file.isDirectory());
			System.out.println("canRead "+file.canRead());
			System.out.println("canWrite "+file.canWrite());
			System.out.println("canExecute "+file.canExecute());
		}else {
			System.out.println("file does not exists");
		}
*/		
		if(file.isFile()) {
			System.out.println("path "+file.getAbsolutePath());
			System.out.println("canRead "+file.canRead());
			System.out.println("canWrite "+file.canWrite());
			System.out.println("canExecute "+file.canExecute());
//			file.renameTo(new File("D:\\FileDemoJava\\mydemo3.txt"));
//			file.delete();
		}else if(file.isDirectory()){
			String[] files = file.list();
			for(String str:files) {
				System.out.println(str);
			}
		}else {
			try {
				file.createNewFile();
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		/*System.out.println(file.getFreeSpace());
		System.out.println(file.getTotalSpace());
		System.out.println(file.getUsableSpace());*/
	}

}
