package org.cap.file;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FromattedInputDemo {

	public static void main(String[] args) {
		
		File file = new File("D:\\FileDemoJava\\sampleFromatted.txt");
		
		try(FileInputStream fileInputStream = new FileInputStream(file);
			DataInputStream dataInputStream = new DataInputStream(fileInputStream)){
			
			int id = dataInputStream.readInt();
			double salary = dataInputStream.readDouble();
			boolean per = dataInputStream.readBoolean();
			char gender = dataInputStream.readChar();
			String name = dataInputStream.readLine();
			
			System.out.println(id);
			System.out.println(salary);
			System.out.println(per);
			System.out.println(gender);
			System.out.println(name);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
