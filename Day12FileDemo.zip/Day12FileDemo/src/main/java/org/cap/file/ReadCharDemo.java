package org.cap.file;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadCharDemo {

	public static void main(String[] args) {

		File file = new File("D:\\FileDemoJava\\sample1.txt");
		
		try(FileReader reader = new FileReader(file)) {
			int c=0;
			while((c = reader.read())!=-1) {
				System.out.print((char)c);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
