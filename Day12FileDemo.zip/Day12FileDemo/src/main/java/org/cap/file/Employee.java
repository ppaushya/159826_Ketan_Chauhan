package org.cap.file;

import java.time.LocalDate;

public class Employee {

	private int empId;
	private String firstName;
	private double salary;
	private char gender;
	private boolean isPermanent;
	
	public Employee() {
		super();
	}

	public Employee(int empId, String firstName, double salary, char gender, boolean isPermanent) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.salary = salary;
		this.gender = gender;
		this.isPermanent = isPermanent;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public boolean isPermanent() {
		return isPermanent;
	}

	public void setPermanent(boolean isPermanent) {
		this.isPermanent = isPermanent;
	}

	
	
}
