package org.cap.file;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharDemo {

	public static void main(String[] args) {

		File file = new File("D:\\FileDemoJava\\sample1.txt");
//		writeFile(file, "Good Afternoon!");
		
		String rev = readFileInReverse(file);
		writeFile(file, rev);
	}
	
	private static void writeFile(File file,String msg) {
		
		try(FileWriter writer = new FileWriter(file)) {
			/*char[] array = greeting.toCharArray();
			for(char c:array) {
				writer.write(c);
			}*/
			writer.write(msg);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static String readFileInReverse(File file) {
		StringBuilder sBuilder = new StringBuilder();
		try(FileReader reader = new FileReader(file)) {
			int c=0;
			while((c = reader.read())!=-1) {
				sBuilder.insert(0, (char)c);
			}
			System.out.println(sBuilder.toString());
			return sBuilder.toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}
}
