package org.cap.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="customer")
public class RegisterPojo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	
	@NotEmpty(message="Enter first name")
	private String firstName;
	private String lastName;
	
	@Email(message = "Enter email")
	@NotEmpty(message="Enter valid email")
	private String emailId;
	private String address;
	private String city;
	private String gender;
	private String qualification;
	
	@Range(min=100,max=5000,message="Enter fees between 100 and 5000")
	private String registrationFees;
	
	@DateTimeFormat(pattern="dd-MMM-yyyy")
	@Past(message="Enter past date")
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;
	
	@Length(min=6,max=16,message="Enter password of length between 6 and 16")
	private String password;
	
	@Transient
	private String confirmPassword;
	
	@OneToOne
	@JoinColumn(name="joinCustomerId")
	private Customer customer;
	
	public RegisterPojo() {
		super();
	}

	public RegisterPojo(int customerId, String firstName, String lastName, String emailId, String address, String city,
			String gender, String qualification, String registrationFees, Date dateOfBirth, String password,
			String confirmPassword) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.registrationFees = registrationFees;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
		this.confirmPassword = confirmPassword;
	}

	
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
	public String getRegistrationFees() {
		return registrationFees;
	}

	public void setRegistrationFees(String registrationFees) {
		this.registrationFees = registrationFees;
	}
	
	

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "RegisterPojo [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", address=" + address + ", city=" + city + ", gender=" + gender
				+ ", qualification=" + qualification + ", registrationFees=" + registrationFees + ", dateOfBirth="
				+ dateOfBirth + ", password=" + password + ", confirmPassword=" + confirmPassword + "]";
	}

	
	
	
}
