package org.cap.service;

import java.util.List;

import org.cap.dao.IRegisterDao;
import org.cap.model.RegisterPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("registerService")
public class RegistrationServiceImpl implements IRegisterService{

	@Autowired
	private IRegisterDao registerDao;

	@Override
	public boolean registerCustomer(RegisterPojo registerPojo) {
		return registerDao.registerCustomer(registerPojo);
	}

	@Override
	public List<RegisterPojo> getAllRegistration() {
		
		return registerDao.getAllRegistration();
	}

	@Override
	public void deleteRegistration(int customerId) {
		registerDao.deleteRegistration(customerId);
		
	}

	@Override
	public RegisterPojo findRegistration(int customerId) {
		return registerDao.findRegistration(customerId);
	}

	@Override
	public void updateRegistration(RegisterPojo registerPojo) {
		registerDao.updateRegistration(registerPojo);
	}
	
	
}
