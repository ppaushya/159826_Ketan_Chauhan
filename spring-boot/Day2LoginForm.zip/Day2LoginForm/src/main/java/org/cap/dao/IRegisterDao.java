package org.cap.dao;

import java.util.List;

import org.cap.model.RegisterPojo;

public interface IRegisterDao {

	public boolean registerCustomer(RegisterPojo registerPojo);
	public void deleteRegistration(int customerId);
	public void updateRegistration(RegisterPojo registerPojo);
	public RegisterPojo findRegistration(int customerId);
	public List<RegisterPojo> getAllRegistration();
}
