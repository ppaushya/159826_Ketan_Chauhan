package org.cap.dao;

import org.cap.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ICustomerDBDao extends JpaRepository<Customer,Integer>{

}
