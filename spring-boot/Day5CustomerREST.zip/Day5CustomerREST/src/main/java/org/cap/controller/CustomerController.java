package org.cap.controller;

import java.util.List;

import org.cap.model.Customer;
import org.cap.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="*") //another server can access methods in this class
@RestController
@RequestMapping("/api")
public class CustomerController {

	@Autowired
	private ICustomerService customerService;

	@GetMapping(value = "/customers")
	public ResponseEntity<List<Customer>> getAllCustomers() {
		List<Customer> customers = customerService.getAllCustomers();
		if (customers.isEmpty()) {
			return new ResponseEntity("No customers", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

	@GetMapping(value = "/customers/{customerId}")
	public ResponseEntity<Customer> getCustomer(@PathVariable("customerId") Integer customerId) {
		Customer customer = customerService.getCustomer(customerId);
		if (customer == null) {
			return new ResponseEntity("No customer", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}
	
	@PostMapping(value = "/customers")
	public ResponseEntity<List<Customer>> insertCustomer(@RequestBody Customer customer) {
		//List<Customer> customers = customerService.updateCustomer(customer);
		List<Customer> customers = customerService.insertCustomer(customer);
		if (customer == null) {
			return new ResponseEntity("Insertion failed", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
	
	@PutMapping(value = "/customers")
	public ResponseEntity<List<Customer>> updateCustomer(@RequestBody Customer customer) {
		List<Customer> customers = customerService.updateCustomer(customer);
		if (customer == null) {
			return new ResponseEntity("Updation failed", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
	
	/*@PatchMapping(value = "/customers")
	public ResponseEntity<List<Customer>> patchCustomer(@RequestBody Customer customer) {
		List<Customer> customers = customerService.updateCustomer(customer);
		if (customer == null) {
			return new ResponseEntity("Updation failed", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}*/

	@DeleteMapping(value = "/customers/{customerId}")
	public ResponseEntity<List<Customer>> deleteCustomer(@PathVariable("customerId") Integer customerId) {
		List<Customer> customers = customerService.deleteCustomer(customerId);

		if (customers == null)
			return new ResponseEntity("Sorry! Customer Id not available!", HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
}
