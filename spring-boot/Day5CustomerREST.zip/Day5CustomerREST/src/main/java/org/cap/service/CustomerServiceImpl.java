package org.cap.service;

import java.util.List;
import java.util.Optional;

import org.cap.dao.ICustomerDBDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("customerService")
public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	private ICustomerDBDao customerDao;
	
	@Override
	public List<Customer> getAllCustomers() {
		return customerDao.findAll();
	}

	@Override
	public Customer getCustomer(int customerId) {
		Optional<Customer> optionalCustomer = customerDao.findById(customerId);
		if(optionalCustomer.isPresent()) {
			return optionalCustomer.get();
		}
		return null;
	}

	@Override
	public List<Customer> insertCustomer(Customer customer) {
		customerDao.save(customer);
		return getAllCustomers();
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		customerDao.save(customer);
		return getAllCustomers();
	}

	@Override
	public List<Customer> deleteCustomer(int customerId) {
		customerDao.deleteById(customerId);
		return getAllCustomers();
	}

}
