package org.cap.service;

import java.util.List;

import org.cap.dao.ICustomerDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("customerService")
public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	private ICustomerDao customerDao;
	
	@Override
	public List<Customer> getAllCustomers() {
		return customerDao.getAllCustomers();
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomer(customerId);
	}

	@Override
	public List<Customer> insertCustomer(Customer customer) {
		return customerDao.insertCustomer(customer);
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		return customerDao.updateCustomer(customer);
	}

	@Override
	public List<Customer> deleteCustomer(int customerId) {
		return customerDao.deleteCustomer(customerId);
	}

}
