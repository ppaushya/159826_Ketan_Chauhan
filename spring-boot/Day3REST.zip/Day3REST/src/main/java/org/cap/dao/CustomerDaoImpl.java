package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("customerDao")
@Transactional
public class CustomerDaoImpl implements ICustomerDao{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> customers= em.createQuery("from Customer").getResultList();
		return customers;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return em.find(Customer.class,customerId);
	}

	@Override
	public List<Customer> insertCustomer(Customer customer) {
		em.persist(customer);
		return getAllCustomers();
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		Customer customer2 = em.find(Customer.class,customer.getCustomerId());
		if(customer2.getCustomerId()==0) {
			em.persist(customer);
		}else {
			em.merge(customer);
		}
		return getAllCustomers();
	}

	@Override
	public List<Customer> deleteCustomer(Integer customerId) {
		Customer customer=em.find(Customer.class, customerId);
		
		if(customer==null)
			return null;
		else
		{
			em.remove(customer);
			return getAllCustomers();
		}
	}

}
