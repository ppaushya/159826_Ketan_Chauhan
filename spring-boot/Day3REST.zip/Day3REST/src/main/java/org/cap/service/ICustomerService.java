package org.cap.service;

import java.util.List;

import org.cap.model.Customer;

public interface ICustomerService {

	public List<Customer> getAllCustomers();
	public Customer getCustomer(int customerId);
	public List<Customer> insertCustomer(Customer customer);
	public List<Customer> updateCustomer(Customer customer);
	public List<Customer> deleteCustomer(int customerId);
}
