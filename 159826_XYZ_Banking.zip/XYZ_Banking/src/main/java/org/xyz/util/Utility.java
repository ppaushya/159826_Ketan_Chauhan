package org.xyz.util;

public class Utility {
	
	/*public static int generateAccountNo() {
		int number=10000;
		boolean sucess = false;
		while(!sucess) {
			number = (int)(Math.random()*10000);
			sucess = Validator.validateAccountNumber(String.valueOf(number));
		}
		return number;
	}*/	
}
