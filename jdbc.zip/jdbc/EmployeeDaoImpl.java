package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements IEmployeeDao{

	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	

	@Override
	public int getLatestEmployeeId() {
		try(Connection connection = getConnection()) {
			String sql = "select max(empid) from employee";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				return resultSet.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return 100;
	}
	
	@Override
	public void createEmployee(Employee employee) {
		try(Connection connection = getConnection()) {
			/*String query = "insert into employee values("+employee.getEmpId()+",'"+employee.getFirstName()
				+"','"+employee.getLastName()+"',"+employee.getSalary()+",'"+employee.getEmpDoj()+"')";
			Statement statement = connection.createStatement();
			int count = statement.executeUpdate(query);
			if(count>0) {
				System.out.println("Record inserted.");
			}else {
				System.out.println("Error occured.");
			}*/
			
			String query = "insert into employee values(?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, employee.getEmpId());
			statement.setString(2, employee.getFirstName());
			statement.setString(3, employee.getLastName());
			statement.setDouble(4, employee.getSalary());
			statement.setDate(5,Date.valueOf(employee.getEmpDoj()));
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Employee inserted.");
			}else {
				System.out.println("Error occured.");
			} 
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}

	@Override
	public void updateEmployee(Employee employee) {
		try(Connection connection = getConnection()) {
			String query = "update employee set firstName=?,lastName=?,salary=?,empdoj=? where empid=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, employee.getFirstName());
			statement.setString(2, employee.getLastName());
			statement.setDouble(3, employee.getSalary());
			statement.setDate(4,Date.valueOf(employee.getEmpDoj()));
			statement.setInt(5, employee.getEmpId());
			
			int count = statement.executeUpdate();   
			if(count>0) {
				System.out.println("Employee updated.");
			}else {
				System.out.println("Error occured.");
			} 
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteEmployee(int employeeId) {
		try(Connection connection = getConnection()) {
			String sql = "delete from employee where empid=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, employeeId);
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Employee deleted.");
			}else {
				System.out.println("Error occured.");
			} 
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}		
	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> employees = new ArrayList<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from employee";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmpId(resultSet.getInt(1));
				employee.setFirstName(resultSet.getString("firstName"));
				employee.setLastName(resultSet.getString("lastName"));
				employee.setSalary(resultSet.getDouble("salary"));
				employee.setEmpDoj(resultSet.getDate(5).toLocalDate());
				employees.add(employee);
			}
			return employees;
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public Employee findEmployee(int employeeId) {
		try(Connection connection = getConnection()) {
			String sql = "select * from employee where empid=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, employeeId);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmpId(resultSet.getInt(1));
				employee.setFirstName(resultSet.getString("firstName"));
				employee.setLastName(resultSet.getString("lastName"));
				employee.setSalary(resultSet.getDouble("salary"));
				employee.setEmpDoj(resultSet.getDate(5).toLocalDate());
				return employee;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public Employee callProcedure(int employeeId) {
		try(Connection connection = getConnection()) {
			CallableStatement statement = connection.prepareCall("{ call findEmployee(?,?,?,?)}");
			statement.setInt(1,employeeId);
			statement.registerOutParameter(2, Types.VARCHAR);
			statement.registerOutParameter(3, Types.VARCHAR);
			statement.registerOutParameter(4, Types.DOUBLE);
			
			statement.execute();
			
			Employee employee = new Employee();
			employee.setEmpId(employeeId);
			employee.setFirstName(statement.getString(2));
			employee.setLastName(statement.getString(3));
			employee.setSalary(statement.getDouble(4));
			
			return employee;
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public void callBulkInsertion() {
		try(Connection connection = getConnection()) {
			String sql1="insert into employee values(1,'tom','jerry',2300,'2001-3-12')";
			String sql2="insert into employee values(2,'tom','jerry',2300,'2001-3-12')";
			String sql3="insert into employee values(3,'tom','jerry',2300,'2001-3-12')";
			String sql4="insert into employee values(4,'tom','jerry',2300,'2001-3-12')";
			String sql5="insert into employee values(5,'tom','jerry',2300,'2001-3-12')";
			
			Statement statement = connection.createStatement();
			statement.addBatch(sql1);
			statement.addBatch(sql2);
			statement.addBatch(sql3);
			statement.addBatch(sql4);
			statement.addBatch(sql5);
			
			int results[] = statement.executeBatch();
			for(int i:results) {
				System.out.println(i);
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
		
	}

}
