package jdbc;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class UserInteraction {

	static Scanner scanner = new Scanner(System.in);
	static int empId = 100;
	
	public static void setEmpId(int employeeId) {
		empId = employeeId;
	}
	
	public static int showMenuAndGetChoice() {
		int choice=0;
		while(choice<1 || choice>8) {
			System.out.println();
			System.out.println("----------------------------------");
			System.out.println("1. Create Employee");
			System.out.println("2. Update Employee");
			System.out.println("3. Delete Employee");
			System.out.println("4. Find Employee");
			System.out.println("5. List all Employee");
			System.out.println("6. Call Stored Procedure");
			System.out.println("7. Bulk Operation");
			System.out.println("8. Exit");
			System.out.println("Enter your choice[1-8]: ");
			choice = scanner.nextInt();
			if(choice<1 || choice>8) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int showUpdateMenuAndGetChoice() {
		int choice=0;
		while(choice<1 || choice>5) {
			System.out.println();
			System.out.println("----------------------------------");
			System.out.println("1. Update first name");
			System.out.println("2. Update last name");
			System.out.println("3. Update salary name");
			System.out.println("4. Update date of joining");
			System.out.println("5. Exit");
			System.out.println("Enter your choice[1,2,3,4,5]: ");
			choice = scanner.nextInt();
			if(choice<1 || choice>5) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static Employee promptEmployee() {
		Employee employee = new Employee();
		employee.setEmpId(++empId);
		System.out.println("Enter first name:");
		employee.setFirstName(scanner.next());
		System.out.println("Enter last name:");
		employee.setLastName(scanner.next());
		System.out.println("Enter salary:");
		employee.setSalary(scanner.nextDouble());
		
		employee.setEmpDoj(getDateFromUser("Enter date of joining [dd-mm-yyyy]:"));
		return employee;
	}
	
	public static Employee promptUpdatedEmployeeDetails(Employee oldEmployee) {
		int choice = showUpdateMenuAndGetChoice();
		switch (choice) {
			case 1:
				System.out.println("Enter first name:");
				oldEmployee.setFirstName(scanner.next());
				break;
			case 2:
				System.out.println("Enter last name:");
				oldEmployee.setLastName(scanner.next());
				break;
			case 3:
				System.out.println("Enter salary:");
				oldEmployee.setSalary(scanner.nextDouble());
				break;
			case 4:
				oldEmployee.setEmpDoj(getDateFromUser("Enter date of joining [dd-mm-yyyy]:"));
				break;
			default:
				break;
		}
		return oldEmployee;
	}
	
	public static int promptEmployeeId() {
		System.out.println("Enter Employee Id:");
		return scanner.nextInt();
	}
	
	private static LocalDate getDateFromUser(String message) {
		String date="";
		while(!date.matches("([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])[-]([1-9]|0[1-9]|1[0-2])[-][1-2][0-9]{3}")) {
			System.out.println(message);
			date = scanner.next();
		}
		String dateParts[] = date.split("-");
		return LocalDate.of(Integer.parseInt(dateParts[2]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[0]));
	}
	
	public static void printEmployees(List<Employee> employees) {
		System.out.println("+-------------------------------------------------------------------------------+");
		System.out.println("|EmployeeId\tFirst Name\tLast Name\tSalary\t\tDate of join\t|");
		System.out.println("+-------------------------------------------------------------------------------+");
		for(Employee employee:employees) {
			System.out.println("|"+employee.getEmpId()+"\t\t"+employee.getFirstName()+"\t\t"+employee.getLastName()+"\t\t"+employee.getSalary()+"\t\t"+employee.getEmpDoj()+"\t|");
		}
		System.out.println("+-------------------------------------------------------------------------------+");
	}
	
	public static void printEmployee(Employee employee) {
		System.out.println("+-------------------------------------------------------------------------------+");
		System.out.println("|EmployeeId\tFirst Name\tLast Name\tSalary\t\tDate of join\t|");
		System.out.println("+-------------------------------------------------------------------------------+");
		System.out.println("|"+employee.getEmpId()+"\t\t"+employee.getFirstName()+"\t\t"+employee.getLastName()+"\t\t"+employee.getSalary()+"\t\t"+employee.getEmpDoj()+"\t|");
		System.out.println("+-------------------------------------------------------------------------------+");
	}
	
	public static boolean getRepeatConfirmation() {
		boolean shouldRepeat = false;
		System.out.println("Do you wish to continue? [y/n]:");
		String choice = scanner.next();
		shouldRepeat = choice.charAt(0)=='y' || choice.charAt(0)=='Y';
		return shouldRepeat;
	}
}
