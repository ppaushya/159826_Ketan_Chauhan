package jdbc;

import java.util.List;

public class TestJDBC {

	public static void main(String[] args) {
		
		IEmployeeDao employeeDao = new EmployeeDaoImpl();
		
		UserInteraction.setEmpId(employeeDao.getLatestEmployeeId());
		/*Employee employee1 = new Employee(101,"Tom","Smith",25000,LocalDate.of(2012, 12, 12));
		Employee employee2 = new Employee(102,"Jerry","Smith",10000,LocalDate.of(2010, 1, 5));
		
		employeeDao.addEmployee(employee1);
		employeeDao.addEmployee(employee2);*/
		
		do {
			int choice = UserInteraction.showMenuAndGetChoice();
			switch (choice) {
				case 1:
					Employee employee = UserInteraction.promptEmployee();
					employeeDao.createEmployee(employee);
					break;
				case 2:
					int empId = UserInteraction.promptEmployeeId();
					Employee employee1 = employeeDao.findEmployee(empId);
					if(employee1!=null) {
						UserInteraction.printEmployee(employee1);
						employee1 = UserInteraction.promptUpdatedEmployeeDetails(employee1);
						employeeDao.updateEmployee(employee1);
					}else {
						System.out.println("No employee exists.");
					}
					break;
				case 3:
					int empId1 = UserInteraction.promptEmployeeId();
					employeeDao.deleteEmployee(empId1);
					break;
				case 4:
					int empId2 = UserInteraction.promptEmployeeId();
					Employee employee2 = employeeDao.findEmployee(empId2);
					if(employee2!=null) {
						UserInteraction.printEmployee(employee2);
					}else {
						System.out.println("No employee exists.");
					}
					break;
				case 5:
					List<Employee> employees = employeeDao.getAllEmployee();
					UserInteraction.printEmployees(employees);					
					break;
				case 6:
					int eId = UserInteraction.promptEmployeeId();
					Employee employee3 = employeeDao.callProcedure(eId);
					if(employee3!=null) {
						UserInteraction.printEmployee(employee3);
					}else {
						System.out.println("No employee exists.");
					}
					break;
				case 7:
					employeeDao.callBulkInsertion();
					break;
				case 8:
					System.out.println("Thank You!");
					System.exit(0);
					break;
				default:
					break;
			}
		}while(UserInteraction.getRepeatConfirmation());
	}
	
	
}
