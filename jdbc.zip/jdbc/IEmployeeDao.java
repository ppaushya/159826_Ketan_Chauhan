package jdbc;

import java.util.List;

public interface IEmployeeDao {

	public int getLatestEmployeeId();
	public void createEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	public List<Employee> getAllEmployee();
	public Employee findEmployee(int employeeId);
	public Employee callProcedure(int employeeId);
	public void callBulkInsertion();
	
}
