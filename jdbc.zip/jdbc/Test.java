package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {

	public static void main(String[] args) {

//		Connection connection = null;
		
		//1. load driver class
//		try {
		try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123")) {
			Class.forName("com.mysql.jdbc.Driver");
			
			//connection establishment
//			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
//			
			//query
			String query1 = "create table employee1(empid int primary key,firstName varchar(25) not null,"
					+ "lastName varchar(25), salary numeric(8,2),empdoj date)";
			Statement statement1 = connection.createStatement();
			
			//execution
			boolean error = statement1.execute(query1);
			if(!error) {
				System.out.println("Table created successfully.");
			}else {
				System.out.println("Error occured.");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}/*finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.toString());
				e.printStackTrace();
			}
		}*/
	}

}
