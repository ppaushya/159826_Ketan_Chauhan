package runnable;

public class MainClass {

	public static void main(String[] args) {

		ThreadDemo r1 = new ThreadDemo();
		
		Thread t1 = new Thread(r1);
//		Thread t2 = new Thread(r1,"capg");
		Thread t2 = new Thread(r1);
		Thread t3 = new Thread(r1);

		t1.start();
		try {
//			t1.join();
			t1.join(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		t2.start();
		try {
//			t2.join();
			t2.join(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		t3.start();
	}

}
