
public class MyThread extends Thread{

	public MyThread() {
		super();
	}
	
	public MyThread(String threadName) {
		super(threadName);
	}

	@Override
	public void run() {
		System.out.println(getName()+" thread started...");
	}
}
