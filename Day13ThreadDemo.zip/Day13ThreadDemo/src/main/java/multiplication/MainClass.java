package multiplication;

public class MainClass {

	public static void main(String[] args) {

		//1
		/*MyThread t1 = new MyThread(13);
		MyThread t2 = new MyThread(15);
		MyThread t3 = new MyThread(21);*/
		
		//2
		/*Thread t1 = new Thread() {
			@Override
			public void run() {
				MyThread.printTable(13);
			}
		};
		Thread t2 = new Thread() {
			@Override
			public void run() {
				MyThread.printTable(15);
			}
		};
		Thread t3 = new Thread() {
			@Override
			public void run() {
				MyThread.printTable(21);
			}
		};*/
		
		//3
		MyThread mThread = new MyThread();
		Runnable r1 = new Runnable() {
			@Override
			public void run() {
				mThread.printTable(13);
			}
		};
		Thread t1 = new Thread(r1);
		
		Runnable r2 = new Runnable() {
			@Override
			public void run() {
				mThread.printTable(15);
			}
		};
		Thread t2 = new Thread(r2);
		
		Runnable r3 = new Runnable() {
			@Override
			public void run() {
				mThread.printTable(21);
			}
		};
		Thread t3 = new Thread(r3);
		
		//run 
		t1.start();
		/*try {
			t1.join();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}*/
		
		t2.start();
		/*try {
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
		
		t3.start();
		
		/*Runnable r4 = new Runnable() {
			@Override
			public void run() {
				for(int i=0;i<1000000;i++) {
					System.out.println(Thread.currentThread().getName()+" "+i);
				}
			}
		};
		Thread t4 = new Thread(r4);
		t4.setDaemon(true);
		t4.start();*/
		
		//System.out.println("Program end...");
	}

}
