package multiplication;

public class MyThread extends Thread{

	int number;
	
	public MyThread() {
		super();
	}
	
	public MyThread(int number) {
		super();
		this.number = number;
	}

	@Override
	public void run() {
		printTable(number);
	}
	
	/*public synchronized void printTable(int number) {
		//this.number = n;
		System.out.println();
		System.out.println("Print table started");
		
		for(int i=1;i<=20;i++) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"->"+number+" * "+i+" = "+number*i);
		}
		
		System.out.println("Print table ended");
		System.out.println();
	}*/
	
	public void printTable(int number) {
		//this.number = n;
		System.out.println();
		System.out.println("Print table started");
		
		synchronized (this) {
			for(int i=1;i<=20;i++) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(Thread.currentThread().getName()+"->"+number+" * "+i+" = "+number*i);
			}
		}
		
		System.out.println("Print table ended");
		System.out.println();
	}
	
	/*public static void printTable(int number) {
		System.out.println();
		for(int i=1;i<=20;i++) {
			System.out.println(Thread.currentThread().getName()+"->"+number+" * "+i+" = "+number*i);
		}
		System.out.println();
	}*/
}
