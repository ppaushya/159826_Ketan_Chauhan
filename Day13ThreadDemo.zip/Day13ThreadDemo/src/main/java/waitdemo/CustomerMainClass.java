package waitdemo;

public class CustomerMainClass {

	public static void main(String[] args) {
		Customer customer = new Customer(5000);
		
		Thread w1 = new Thread() {
			@Override
			public void run() {
				customer.withdraw(8000);
			}
		};
		w1.start();
		
		Thread w2 = new Thread() {
			@Override
			public void run() {
				customer.withdraw(6000);
			}
		};
		w2.start();
		
		Thread d1 = new Thread() {
			@Override
			public void run() {
				customer.deposit(14000);
			}
		};                                                                                                                  
		d1.start();
		
//		w1.setPriority(10);
//		w1.yield();

		/*System.out.println(w1.getPriority());
		System.out.println(w2.getPriority());
		System.out.println(d1.getPriority());*/
	}

}
