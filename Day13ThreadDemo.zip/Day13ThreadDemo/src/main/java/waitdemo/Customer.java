package waitdemo;

public class Customer {

	int amount;
	
	public Customer(int amount) {
		super();
		this.amount = amount;
	}

	public synchronized void withdraw(int amt) {
		if(this.amount<amt) {
			System.out.println("-----Withdraw-----");
			System.out.println("current amount: "+amount);
			try {
				System.out.println("Insufficient amount. Waiting ....");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(this.amount>=amt) {
			System.out.println("-----Withdraw-----");
			System.out.println("current amount: "+amount);
			System.out.println("withdrawing...");
			this.amount -= amt;
			System.out.println("Updated amount after withdraw: "+amount);
		}
		
	}
	
	public synchronized void deposit(int amt) {
		System.out.println("-----Deposit-----");
		System.out.println("current amount: "+amount);
		this.amount += amt;
		System.out.println("Updated amount after deposit: "+amount);
		System.out.println("notifying... ");
//		notify();
		notifyAll();
	}
}
