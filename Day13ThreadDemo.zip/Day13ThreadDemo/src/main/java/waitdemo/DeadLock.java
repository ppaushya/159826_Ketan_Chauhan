package waitdemo;

public class DeadLock {

	public static void main(String[] args) {

		Thread t1 = new Thread() {
			@Override
			public void run() {
				
				synchronized (this) {
					
				}
			}
		};
	}

}
