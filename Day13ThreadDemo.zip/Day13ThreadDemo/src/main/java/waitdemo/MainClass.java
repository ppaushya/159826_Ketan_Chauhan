package waitdemo;

public class MainClass {

	public static void main(String[] args) {

		Product product = new Product(50);
		
		Thread con1 = new Thread() {
			@Override
			public void run() {
				product.consume(80);
			}
		};
		con1.start();
		
		Thread con2 = new Thread() {
			@Override
			public void run() {
				product.consume(60);
			}
		};
		con2.start();
		
		Thread pro = new Thread() {
			@Override
			public void run() {
				product.produce(40);
			}
		};
		pro.start();
	}

}
