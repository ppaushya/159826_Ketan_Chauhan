package waitdemo;

public class Product {

	int quantity;
	
	
	public Product(int quantity) {
		super();
		this.quantity = quantity;
	}

	public synchronized void consume(int qty) {
		System.out.println("Consuming....");
		System.out.println("current quantity: "+quantity);
		if(this.quantity<qty) {
			try {
				System.out.println("Insufficient quantity. Waiting ....");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		System.out.println("resumed");
		this.quantity -= qty;
		System.out.println("Updated quantity after consume: "+quantity);
	}
	
	public synchronized void produce(int qty) {
		System.out.println("producing quantity... ");
		System.out.println("current quantity: "+quantity);
		this.quantity += qty;
		System.out.println("notifying... ");
		System.out.println("Updated quantity after produce: "+quantity);
//		notify();
		notifyAll();
	}
}
