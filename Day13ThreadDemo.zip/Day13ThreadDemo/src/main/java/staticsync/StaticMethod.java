package staticsync;

public class StaticMethod {

	static int count = 1;
	
	public static void main(String[] args) {

	}

}
