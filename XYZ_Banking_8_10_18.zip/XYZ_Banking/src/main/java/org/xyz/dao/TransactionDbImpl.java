package org.xyz.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.xyz.model.Account;
import org.xyz.model.AccountType;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;

public class TransactionDbImpl implements ITransactionDao{

	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Set<Transaction> getAllTransactions() {
		Set<Transaction> transactions = new HashSet<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from transaction";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getAllTransactionsOfCustomer(Customer customer) {
		Set<Transaction> transactions = new HashSet<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from transaction t, account a1 , account a2 "
					+ "where t.fromAccountNumber = a1.accountNumber and t.toAccountNumber = a2.accountNumber "
					+ "and (a1.customerId = ? or a2.customerId=?)";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customer.getCustomerId());
			statement.setLong(2, customer.getCustomerId());
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getAllTransactionsOfAccount(Account account) {
		Set<Transaction> transactions = new HashSet<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from transaction where fromAccountNumber=? or toAccountNumber=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, account.getAccountNumber());
			statement.setLong(2, account.getAccountNumber());
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	private Set<Transaction> getAllTransactionsFromCursor(ResultSet resultSet) throws SQLException {
		Set<Transaction> transactions = new HashSet<>();
		
		while(resultSet.next()) {
			Transaction transaction = new Transaction();
			transaction.setTransactionId(resultSet.getLong("transactionId"));
			transaction.setTransactionDate(resultSet.getDate("transactionDate").toLocalDate());
			
			AccountDbImpl accountDbImpl = new AccountDbImpl(null);
			Account fromAccount = accountDbImpl.getAccountFromAccountId(resultSet.getLong("fromAccountNumber"));
			Account toAccount = accountDbImpl.getAccountFromAccountId(resultSet.getLong("toAccountNumber"));
			transaction.setFromAccount(fromAccount);
			transaction.setToAccount(toAccount);
			
			transaction.setAmount(resultSet.getDouble("amount"));
			transaction.setTransactionType(resultSet.getString("transactionType"));
			transaction.setDescription(resultSet.getString("description"));
			
			transactions.add(transaction);
		}
//		System.out.println("s "+transactions.size());
		return transactions;
	}

	@Override
	public void createTransaction(Transaction transaction) {
		try(Connection connection = getConnection()) {
			
			String query = "insert into transaction values(null,?,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setDate(1, Date.valueOf(transaction.getTransactionDate()));
			statement.setLong(2, transaction.getFromAccount().getAccountNumber());
			statement.setLong(3, transaction.getToAccount().getAccountNumber());
			statement.setDouble(4, transaction.getAmount());
			statement.setString(5, transaction.getTransactionType());
			statement.setString(6, transaction.getDescription());
			
			if(statement.executeUpdate()>0) {
				System.out.println("Transaction inserted.");
			}else {
				System.out.println("Error occured.");
			} 
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}

}
