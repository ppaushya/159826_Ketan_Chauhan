package org.xyz.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.xyz.model.Address;
import org.xyz.model.Customer;
import org.xyz.util.IdGenerator;

public class CustomerDbImpl implements ICustomerDao{

	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	private int getLatestAddressId() {
		try(Connection connection = getConnection()) {
			String sql = "select max(addressId) from address";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				return resultSet.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return 100;
	}
	
	public List<Customer> getAllCustomers() {
		List<Customer> customers = new ArrayList<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from customer join address using(addressId)";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Address address = new Address();
				address.setAddressId(resultSet.getInt("addressId"));
				address.setAddressLine1(resultSet.getString("addressLine1"));
				address.setAddressLine2(resultSet.getString("addressLine2"));
				address.setCity(resultSet.getString("city"));
				address.setState(resultSet.getString("state"));
				address.setPincode(resultSet.getString("pincode"));
				
				Customer customer = new Customer();
				customer.setCustomerId(resultSet.getLong("customerId"));
				customer.setFirstName(resultSet.getString("firstName"));
				customer.setLastName(resultSet.getString("lastName"));
				customer.setDateOfBirth(resultSet.getDate("dateOfBirth").toLocalDate());
				customer.setEmailId(resultSet.getString("email"));
				customer.setMobileNo(resultSet.getString("mobileNo"));
				customer.setAddress(address);
				
				AccountDbImpl accountDbImpl = new AccountDbImpl(customer);
				customer.setAccounts(accountDbImpl.getAllAccounts());
				
				customers.add(customer);
			}
			return customers;
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	public void createCustomer(Customer customer) {
		try(Connection connection = getConnection()) {
			//address
			Address address = customer.getAddress();
			int addressId = getLatestAddressId()+1;
			address.setAddressId(addressId);
			
			String addressQuery = "insert into address values(?,?,?,?,?,?)";
			PreparedStatement addressStatement = connection.prepareStatement(addressQuery);
			addressStatement.setInt(1,address.getAddressId());
			addressStatement.setString(2,address.getAddressLine1());
			addressStatement.setString(3,address.getAddressLine2());
			addressStatement.setString(4,address.getCity());
			addressStatement.setString(5,address.getState());
			addressStatement.setString(6,address.getPincode());
			if(addressStatement.executeUpdate()>0) {
				
				String query = "insert into customer values(null,?,?,?,?,?,?)";
				PreparedStatement statement = connection.prepareStatement(query);
				statement.setString(1, customer.getFirstName());
				statement.setString(2, customer.getLastName());
				statement.setDate(3, Date.valueOf(customer.getDateOfBirth()));
				statement.setString(4, customer.getEmailId());
				statement.setString(5, customer.getMobileNo());
				statement.setInt(6, address.getAddressId());
				
				if(statement.executeUpdate()>0) {
					System.out.println("Customer inserted.");
				}else {
					System.out.println("Error occured.");
				} 
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}

	public Customer getCustomerFromCustomerId(long customerId) {
		List<Customer> customers = new ArrayList<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from customer join address using(addressId) where customerId=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customerId);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				Address address = new Address();
				address.setAddressId(resultSet.getInt("addressId"));
				address.setAddressLine1(resultSet.getString("addressLine1"));
				address.setAddressLine2(resultSet.getString("addressLine2"));
				address.setCity(resultSet.getString("city"));
				address.setState(resultSet.getString("state"));
				address.setPincode(resultSet.getString("pincode"));
				
				Customer customer = new Customer();
				customer.setCustomerId(resultSet.getLong("customerId"));
				customer.setFirstName(resultSet.getString("firstName"));
				customer.setLastName(resultSet.getString("lastName"));
				customer.setDateOfBirth(resultSet.getDate("dateOfBirth").toLocalDate());
				customer.setEmailId(resultSet.getString("email"));
				customer.setMobileNo(resultSet.getString("mobileNo"));
				customer.setAddress(address);
				
				AccountDbImpl accountDbImpl = new AccountDbImpl(customer);
				customer.setAccounts(accountDbImpl.getAllAccounts());
				
				return customer;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

}
