package org.file.employee;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class EmployeeStorage {

	static String filePath = "D:\\employees.dat";
	
	public static void writeOnFile(List<Employee> employees) {
		File file = new File(filePath);
		
		try(FileOutputStream fileOutputStream = new FileOutputStream(file);
			DataOutputStream dataOutputStream = new DataOutputStream(fileOutputStream)){
			
			for(Employee employee:employees) {
				dataOutputStream.writeInt(employee.getEmpId());
				dataOutputStream.writeDouble(employee.getSalary());
				dataOutputStream.writeChar(employee.getGender());
				dataOutputStream.writeBoolean(employee.isPermanent());
				
				char[] name = employee.getFirstName().toCharArray();
				dataOutputStream.writeInt(name.length);
				for(int i=0;i<name.length;i++) {
					dataOutputStream.writeChar(name[i]);
				}
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void readFromFile(int len) {
		File file = new File(filePath);
		
		try(FileInputStream fileInputStream = new FileInputStream(file);
			DataInputStream dataInputStream = new DataInputStream(fileInputStream)){
			
			for(int i=0;i<len;i++) {
				int id = dataInputStream.readInt();
				double salary = dataInputStream.readDouble();
				char gender = dataInputStream.readChar();
				boolean per = dataInputStream.readBoolean();
				
				int nameLength = dataInputStream.readInt();
				StringBuffer sBuffer = new StringBuffer();
				for(int l=0;l<nameLength;l++) {
					sBuffer.append(dataInputStream.readChar());
				}
				
				System.out.println("Employee id: "+id);
				System.out.println("Name: "+sBuffer.toString());
				System.out.println("Salary: "+salary);
				System.out.println("Gender: "+gender);
				System.out.println("is permanent: "+per);
				System.out.println();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
