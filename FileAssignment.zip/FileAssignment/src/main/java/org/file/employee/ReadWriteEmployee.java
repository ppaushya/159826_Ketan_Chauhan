package org.file.employee;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadWriteEmployee {
	
	static Scanner scanner = new Scanner(System.in);
	static int empId = 100;
	static List<Employee> employees = new ArrayList<>();

	public static void main(String[] args) {
		int len = 5;
		for(int i=0;i<len;i++) {
			Employee employee = promptEmployee();
			employees.add(employee);
		}
		EmployeeStorage.writeOnFile(employees);
		EmployeeStorage.readFromFile(len);
	}

	public static Employee promptEmployee() {
		System.out.println();
		Employee employee = new Employee();
		employee.setEmpId(++empId);
		
		System.out.println("Enter first name:");
		employee.setFirstName(scanner.next());
		
		System.out.println("Enter salary:");
		employee.setSalary(scanner.nextDouble());
		
		System.out.println("Enter gender:");
		employee.setGender(scanner.next().charAt(0));
		
		System.out.println("Is employee permanent?:");
		char s = scanner.next().charAt(0);
		employee.setPermanent(s=='y'||s=='Y');
		
		return employee;
	}
	
	
}
