package org.file.product;

import java.util.ArrayList;
import java.util.List;

public class BootClass {

	public static void main(String[] args) {
		
		List<Product> products = new ArrayList<>(); 
		
		do {
			Product product = ReadWriteProduct.promptEmployee();
			products.add(product);
			
		}while(ReadWriteProduct.getRepeatConfirmation());
		
	
		ReadWriteProduct.writeOnFile(products);
		ReadWriteProduct.readFromFile();
	}

}
