package org.file.product;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadWriteProduct {
	
	static Scanner scanner = new Scanner(System.in);
	static int prodId = 100;
	static List<Product> products = new ArrayList<>();

	public static Product promptEmployee() {
		Product product = new Product();
		
		System.out.println("Enter product name:");
		product.setName(scanner.next());
		
		System.out.println("Enter quantity:");
		product.setQuantity(scanner.nextInt());
		
		System.out.println("Enter price:");
		product.setPrice(scanner.nextDouble());
		
		product.setExpiryDate(getDateFromUser("Enter expiry date:"));
		
		return product;
	}
	
	private static LocalDate getDateFromUser(String message) {
		String date="10";
		while(!date.matches("([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])[-]([1-9]|0[1-9]|1[0-2])[-][1-2][0-9]{3}")) {
			System.out.println(message);
			date = scanner.next();
		}
		System.out.println("date "+date);
		String dateParts[] = date.split("-");
		return LocalDate.of(Integer.parseInt(dateParts[2]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[0]));
	}
	
	public static boolean getRepeatConfirmation() {
		boolean shouldRepeat = false;
		System.out.println("Do you wish to continue? [y/n]:");
		String choice = scanner.next();
		shouldRepeat = choice.charAt(0)=='y' || choice.charAt(0)=='Y';
		return shouldRepeat;
	}
	
	public static void writeOnFile(List<Product> products) {
		File file = new File("D:\\FileDemoJava\\products.txt");
		
		try(FileOutputStream fileOutputStream = new FileOutputStream(file);
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)){
			
//			Product product = new Product(101, "Mobile", 10, 15000, LocalDate.of(2050, 12, 12));
				for(Product product:products) {
					objectOutputStream.writeObject(product);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	
	public static void readFromFile() {
		File file = new File("D:\\FileDemoJava\\products.txt");
		
		FileInputStream inputStream=null;
		ObjectInputStream objectInputStream = null;
		try	{
			inputStream = new FileInputStream(file);
			objectInputStream = new ObjectInputStream(inputStream);
				
				Product product;
				/*while((product = (Product) objectInputStream.readObject()) != null) {
					System.out.println(product);
				}*/
				do {
					product = (Product) objectInputStream.readObject();
					System.out.println(product);
				}while(objectInputStream != null);

			} catch (IOException | ClassNotFoundException e) {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
				e.printStackTrace();
			}
	}
}
