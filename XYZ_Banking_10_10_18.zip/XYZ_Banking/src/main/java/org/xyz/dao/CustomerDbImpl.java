package org.xyz.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.xyz.model.Address;
import org.xyz.model.Customer;
import org.xyz.util.IdGenerator;

public class CustomerDbImpl implements ICustomerDao{

	private Connection getConnection() {
		Connection connection = null;
		try {
			File dbPropertiesFile = new File("mysqldb.properties");
			FileInputStream inputStream = new FileInputStream(dbPropertiesFile);
			Properties properties = new Properties();
			properties.load(inputStream);
			
			Class.forName(properties.getProperty("driverClass"));
			connection = DriverManager.getConnection(properties.getProperty("url")
					, properties.getProperty("user"), properties.getProperty("password"));
			return connection;
		} catch (ClassNotFoundException | SQLException | IOException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	/*private int getLatestCustomerId() {
		try(Connection connection = getConnection()) {
			String sql = "select max(customerId) from customer";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				int r= resultSet.getInt(1);
				System.out.println("r "+r);
				return r;
				return resultSet.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return 100;
	}*/
	
	public List<Customer> getAllCustomers() {
		List<Customer> customers = new ArrayList<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from customer join address using(customerId)";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Address address = new Address();
				address.setAddressId(resultSet.getInt("addressId"));
				address.setAddressLine1(resultSet.getString("addressLine1"));
				address.setAddressLine2(resultSet.getString("addressLine2"));
				address.setCity(resultSet.getString("city"));
				address.setState(resultSet.getString("state"));
				address.setPincode(resultSet.getString("pincode"));
				
				Customer customer = new Customer();
				customer.setCustomerId(resultSet.getLong("customerId"));
				customer.setFirstName(resultSet.getString("firstName"));
				customer.setLastName(resultSet.getString("lastName"));
				customer.setDateOfBirth(resultSet.getDate("dateOfBirth").toLocalDate());
				customer.setEmailId(resultSet.getString("email"));
				customer.setMobileNo(resultSet.getString("mobileNo"));
				customer.setAddress(address);
				
				AccountDbImpl accountDbImpl = new AccountDbImpl(customer);
				customer.setAccounts(accountDbImpl.getAllAccounts());
				
				customers.add(customer);
			}
			return customers;
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	public void createCustomer(Customer customer) {
		Connection connection = null;
		try{
			connection = getConnection();
			connection.setAutoCommit(false);
			
			String query = "insert into customer values(null,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, customer.getFirstName());
			statement.setString(2, customer.getLastName());
			statement.setDate(3, Date.valueOf(customer.getDateOfBirth()));
			statement.setString(4, customer.getEmailId());
			statement.setString(5, customer.getMobileNo());
			int c1 = statement.executeUpdate();
			
			int customerId = 100;
			String sql = "select max(customerId) from customer";
			PreparedStatement statementForId = connection.prepareStatement(sql);
			ResultSet resultSet = statementForId.executeQuery();
			if(resultSet.next()) {
				customerId = resultSet.getInt(1);
			}
			Address address = customer.getAddress();
			address.setCustomerId(customerId);
			
			String addressQuery = "insert into address values(null,?,?,?,?,?,?)";
			PreparedStatement addressStatement = connection.prepareStatement(addressQuery);
			addressStatement.setInt(1,customerId);
			addressStatement.setString(2,address.getAddressLine1());
			addressStatement.setString(3,address.getAddressLine2());
			addressStatement.setString(4,address.getCity());
			addressStatement.setString(5,address.getState());
			addressStatement.setString(6,address.getPincode());
			int c2 = addressStatement.executeUpdate();
				
			if(c1>0 && c2>0) {
				System.out.println("Customer inserted.");
				connection.commit();
			}else {
				System.out.println("Error occured.");
				connection.rollback();
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			System.out.println(e.toString());
			e.printStackTrace();
		}finally {
			try {
				connection.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Customer getCustomerFromCustomerId(long customerId) {
		List<Customer> customers = new ArrayList<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from customer join address using(customerId) where customerId=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customerId);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				Address address = new Address();
				address.setAddressId(resultSet.getInt("addressId"));
				address.setAddressLine1(resultSet.getString("addressLine1"));
				address.setAddressLine2(resultSet.getString("addressLine2"));
				address.setCity(resultSet.getString("city"));
				address.setState(resultSet.getString("state"));
				address.setPincode(resultSet.getString("pincode"));
				
				Customer customer = new Customer();
				customer.setCustomerId(resultSet.getLong("customerId"));
				customer.setFirstName(resultSet.getString("firstName"));
				customer.setLastName(resultSet.getString("lastName"));
				customer.setDateOfBirth(resultSet.getDate("dateOfBirth").toLocalDate());
				customer.setEmailId(resultSet.getString("email"));
				customer.setMobileNo(resultSet.getString("mobileNo"));
				customer.setAddress(address);
				
				AccountDbImpl accountDbImpl = new AccountDbImpl(customer);
				customer.setAccounts(accountDbImpl.getAllAccounts());
				
				return customer;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

}
