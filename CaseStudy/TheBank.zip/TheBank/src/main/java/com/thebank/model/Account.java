package com.thebank.model;

import java.time.LocalDate;

public class Account {
	
	private long customerId;
	private long accountId;
	private AccountType	accountType;
	private LocalDate openDate;
	private double accountBalance;
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public AccountType getAccountType() {
		return accountType;
	}
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	public LocalDate getOpenDate() {
		return openDate;
	}
	public void setOpenDate(LocalDate openDate) {
		this.openDate = openDate;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	@Override
	public String toString() {
		return "Account [customerId=" + customerId + ", accountId=" + accountId + ", accountType=" + accountType
				+ ", openDate=" + openDate + ", accountBalance=" + accountBalance + "]";
	}
	public Account() {
		super();
	}
	public Account(long accountId, AccountType accountType, LocalDate openDate, double accountBalance) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.openDate = openDate;
		this.accountBalance = accountBalance;
	}
}
