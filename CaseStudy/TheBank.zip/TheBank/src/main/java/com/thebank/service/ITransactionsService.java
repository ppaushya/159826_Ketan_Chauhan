package com.thebank.service;

import java.util.Set;

import com.thebank.model.Transactions;

public interface ITransactionsService {

	public boolean addTransaction();
	public Set<Transactions> getAllTransaction();
	public Set<Transactions> getTransactionsForAccount(long accountId);
	public Set<Transactions> getTransactionsForCustomer(long customerId);
}
