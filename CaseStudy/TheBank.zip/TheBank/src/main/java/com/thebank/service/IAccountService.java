package com.thebank.service;

import java.util.Set;

import com.thebank.model.Account;

public interface IAccountService {

	public boolean addAccount();
	public Set<Account> getAccounts(long customerId);
}
