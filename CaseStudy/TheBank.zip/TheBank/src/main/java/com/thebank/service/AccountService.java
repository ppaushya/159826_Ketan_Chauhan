package com.thebank.service;

import java.util.Set;

import com.thebank.dao.AccountDao;
import com.thebank.dao.IAccountDao;
import com.thebank.model.Account;

public class AccountService implements IAccountService{

	IAccountDao accountDao=new AccountDao();
	
	public boolean addAccount() {
		// TODO Auto-generated method stub
		return accountDao.addAccount();
	}

	@Override
	public Set<Account> getAccounts(long customerId) {
		// TODO Auto-generated method stub
		return accountDao.getAccounts(customerId);
	}

	

}
