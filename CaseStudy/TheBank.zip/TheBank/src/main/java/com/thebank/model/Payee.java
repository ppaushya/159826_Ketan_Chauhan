package com.thebank.model;

public class Payee {
	
	private long accountId;
	private long payeeAccountId;
	private String nickname;
	
	public Payee() {
		super();
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(long payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	@Override
	public String toString() {
		return "Payee [accountId=" + accountId + ", payeeAccountId=" + payeeAccountId + ", nickname=" + nickname
				+ "]";
	}
	public Payee(long accountId, long payeeAccountId, String nickname) {
		super();
		this.accountId = accountId;
		this.payeeAccountId = payeeAccountId;
		this.nickname = nickname;
	}
}
