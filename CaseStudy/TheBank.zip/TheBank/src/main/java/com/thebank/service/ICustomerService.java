package com.thebank.service;

import com.thebank.model.Customer;

public interface ICustomerService {

	public boolean addCustomer();
	public Customer getCustomer(long customerId);
	public boolean changeCustomerMobileNo(Customer customer);
	public boolean changeCustomerAddress(Customer customer);
}
