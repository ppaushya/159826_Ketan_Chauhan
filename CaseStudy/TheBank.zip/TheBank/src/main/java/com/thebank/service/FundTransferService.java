package com.thebank.service;

import java.util.Set;

import com.thebank.dao.FundTransferDao;
import com.thebank.dao.IFundTransferDao;
import com.thebank.model.FundTransfer;

public class FundTransferService implements IFundTransferService{

	IFundTransferDao fundTransferDao = new FundTransferDao();

	@Override
	public boolean addFundTransfer(FundTransfer fundTransfer) {
		// TODO Auto-generated method stub
		return fundTransferDao.addFundTransfer(fundTransfer);
	}

	@Override
	public FundTransfer getFundTransferFromFundTranferId(long fundTranferId) {
		// TODO Auto-generated method stub
		return fundTransferDao.getFundTransferFromFundTranferId(fundTranferId);
	}

	@Override
	public Set<FundTransfer> getAllFundTransfers() {
		// TODO Auto-generated method stub
		return fundTransferDao.getAllFundTransfers();
	}

	@Override
	public Set<FundTransfer> getAllFundTransfersFromAccountId(long accountId) {
		// TODO Auto-generated method stub
		return fundTransferDao.getAllFundTransfersFromAccountId(accountId);
	}
	
	

}
