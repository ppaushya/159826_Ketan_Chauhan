package com.thebank.service;

import java.util.Set;

import com.thebank.dao.IServiceTrackerDao;
import com.thebank.dao.ServiceTrackerDao;
import com.thebank.model.ServiceTracker;

public class ServiceTrackerService implements IServiceTrackerService{

	IServiceTrackerDao serviceTrackerDao=new ServiceTrackerDao();

	@Override
	public boolean addService() {
		// TODO Auto-generated method stub
		return serviceTrackerDao.addService();
	}

	@Override
	public Set<ServiceTracker> getService(int accountId) {
		// TODO Auto-generated method stub
		return serviceTrackerDao.getService(accountId);
	}
	
	

}
