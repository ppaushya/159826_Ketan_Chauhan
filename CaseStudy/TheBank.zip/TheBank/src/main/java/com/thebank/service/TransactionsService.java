package com.thebank.service;

import java.util.Set;

import com.thebank.dao.ITransactionsDao;
import com.thebank.dao.TransactionsDao;
import com.thebank.model.Transactions;

public class TransactionsService implements ITransactionsService{

	ITransactionsDao transactionDao=new TransactionsDao();
	
	@Override
	public boolean addTransaction() {
		// TODO Auto-generated method stub
		return transactionDao.addTransaction();
	}

	@Override
	public Set<Transactions> getAllTransaction() {
		// TODO Auto-generated method stub
		return transactionDao.getAllTransaction();
	}

	@Override
	public Set<Transactions> getTransactionsForAccount(long accountId) {
		// TODO Auto-generated method stub
		return transactionDao.getTransactionsForAccount(accountId);
	}

	@Override
	public Set<Transactions> getTransactionsForCustomer(long customerId) {
		// TODO Auto-generated method stub
		return transactionDao.getTransactionsForCustomer(customerId);
	}

	

}
