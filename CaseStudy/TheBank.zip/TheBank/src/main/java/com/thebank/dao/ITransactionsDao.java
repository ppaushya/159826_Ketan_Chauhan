package com.thebank.dao;

import java.util.Set;

import com.thebank.model.Transactions;

public interface ITransactionsDao {

	public boolean addTransaction();
	public Set<Transactions> getAllTransaction();
	public Set<Transactions> getTransactionsForAccount(long accountId);
	public Set<Transactions> getTransactionsForCustomer(long customerId);
}
