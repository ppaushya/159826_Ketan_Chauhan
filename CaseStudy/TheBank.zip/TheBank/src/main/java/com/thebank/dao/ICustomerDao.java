package com.thebank.dao;

import com.thebank.model.Customer;

public interface ICustomerDao {

	public boolean addCustomer();
	public Customer getCustomer(long customerId);
	public boolean changeCustomerMobileNo(Customer customer);
	public boolean changeCustomerAddress(Customer customer);
}
