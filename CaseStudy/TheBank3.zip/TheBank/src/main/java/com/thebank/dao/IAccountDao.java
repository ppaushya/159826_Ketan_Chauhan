package com.thebank.dao;

import java.util.Set;

import com.thebank.model.Account;

public interface IAccountDao {

	public boolean addAccount();
	public Set<Account> getAccounts(long customerId);
}