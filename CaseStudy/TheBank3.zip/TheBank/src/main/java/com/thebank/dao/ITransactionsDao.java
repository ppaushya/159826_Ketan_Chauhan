package com.thebank.dao;

import java.util.Set;

import com.thebank.model.Transaction;

public interface ITransactionsDao {

	public boolean addTransaction();
	public Set<Transaction> getAllTransaction();
	public Set<Transaction> getTransactionsForAccount(long accountId);
	public Set<Transaction> getTransactionsForCustomer(long customerId);
}
