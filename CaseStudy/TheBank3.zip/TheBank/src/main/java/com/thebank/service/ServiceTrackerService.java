package com.thebank.service;

import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.ServiceTracker;

public class ServiceTrackerService implements IServiceTrackerService{

	public boolean addService() {
		// TODO Auto-generated method stub
		return false;
	}

	public Set<ServiceTracker> getService() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addChequebookRequest(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ServiceTracker getServiceFromServiceId(long serviceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<ServiceTracker> getAllServicesOfCustomer(long customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<ServiceTracker> getAllServicesOfAccount(long accountId) {
		// TODO Auto-generated method stub
		return null;
	}

}
