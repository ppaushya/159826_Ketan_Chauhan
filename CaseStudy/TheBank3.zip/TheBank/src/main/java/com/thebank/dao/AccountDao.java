package com.thebank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.ResolverStyle;
import java.util.HashSet;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.AccountType;

public class AccountDao implements IAccountDao{

	public boolean addAccount() {
		
		String mysql = "insert into accountmaster(customerId, accountType, accountBalance, openDate) values(?,?,?,?)";
		Account account=new Account();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			
			PreparedStatement statement=conn.prepareStatement(mysql);
			statement.setLong(1, account.getCustomerId());
			statement.setString(2, account.getAccountType().toString());
			statement.setDouble(3, account.getAccountBalance());
			statement.setDate(4, Date.valueOf(account.getOpenDate()));
			
			int count=statement.executeUpdate();
			if(count>0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public Set<Account> getAccounts(long customerId) {
		
		String mysql = "select * from accountmaster where customerId = ?";
		Account account=new Account();
		Set<Account> accountSet = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				
				account.setAccountBalance(resultSet.getDouble(4));
				account.setAccountId(resultSet.getLong(1));
				account.setAccountType(AccountType.valueOf(resultSet.getString(3)));
				account.setOpenDate(resultSet.getDate(5).toLocalDate());
				
				accountSet.add(account);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return accountSet;
	}
}
