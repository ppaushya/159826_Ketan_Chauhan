package com.thebank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.thebank.model.ServiceTracker;

public class ServiceTrackerDao implements IServiceTrackerDao{

	public boolean addServiceTracker(ServiceTracker serviceTracker) {
		
		String mysql = "insert into servicetracker(serviceDescription, accountId, serviceRaisedDate, serviceStatus) values(?,?,?,?)";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			
			PreparedStatement statement=conn.prepareStatement(mysql);
			statement.setString(1, serviceTracker.getServiceDescription());
			statement.setLong(2, serviceTracker.getAccountId());
			statement.setDate(3, Date.valueOf(serviceTracker.getServiceRaisedDate()));
			statement.setString(4, serviceTracker.getServiceStatus());
			
			int count=statement.executeUpdate();
			if(count>0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public ServiceTracker getServiceFromServiceId(long serviceId) {
		String mysql = "select * from servicetracker where serviceId = ?";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, serviceId);
			ResultSet resultSet= pst.executeQuery();
			
			if(resultSet.next()) {
				ServiceTracker serviceTracker=new ServiceTracker();
				
				serviceTracker.setServiceId(serviceId);
				serviceTracker.setServiceDescription(resultSet.getString(2));
				serviceTracker.setAccountId(resultSet.getLong(3));
				serviceTracker.setServiceRaisedDate(resultSet.getDate(4).toLocalDate());
				serviceTracker.setServiceStatus(resultSet.getString(5));
			
				return serviceTracker;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return null;	
	}

	@Override
	public Set<ServiceTracker> getAllServicesOfCustomer(long customerId) {
		String mysql = "select * from"
				+ " servicetracker join accountMaster using(accountId)"
				+ " where customerId = ?";
		Set<ServiceTracker> serviceTrackers = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				ServiceTracker serviceTracker=new ServiceTracker();
				
				serviceTracker.setServiceId(resultSet.getLong("serviceId"));
				serviceTracker.setServiceDescription(resultSet.getString("serviceDescription"));
				serviceTracker.setAccountId(resultSet.getLong("accountId"));
				serviceTracker.setServiceRaisedDate(resultSet.getDate("serviceRaisedDate").toLocalDate());
				serviceTracker.setServiceStatus(resultSet.getString("serviceStatus"));
			
				serviceTrackers.add(serviceTracker);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return serviceTrackers;		
	}

	@Override
	public Set<ServiceTracker> getAllServicesOfAccount(long accountId) {
		String mysql = "select * from servicetracker where accountId = ?";
		Set<ServiceTracker> serviceTrackers = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, accountId);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				ServiceTracker serviceTracker=new ServiceTracker();
				
				serviceTracker.setServiceId(resultSet.getLong(1));
				serviceTracker.setServiceDescription(resultSet.getString(2));
				serviceTracker.setAccountId(accountId);
				serviceTracker.setServiceRaisedDate(resultSet.getDate(4).toLocalDate());
				serviceTracker.setServiceStatus(resultSet.getString(5));
			
				serviceTrackers.add(serviceTracker);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return serviceTrackers;
	}

}
