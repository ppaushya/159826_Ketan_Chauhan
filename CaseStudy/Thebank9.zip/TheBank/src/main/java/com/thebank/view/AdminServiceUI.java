package com.thebank.view;

import java.util.Set;

import com.thebank.dao.AccountDao;
import com.thebank.dao.IAccountDao;
import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.Transaction;
import com.thebank.service.CustomerService;
import com.thebank.service.ICustomerService;
import com.thebank.service.ITransactionsService;
import com.thebank.service.TransactionsService;

public class AdminServiceUI {
static ICustomerService customerService=new CustomerService();
static IAccountDao accountDao = new AccountDao();
static ITransactionsService transactionsService=new TransactionsService();

	public static void createNewAccount() {
		Customer customer = PromptUI.getCustomerChoice(customerService.getAllCustomers());
		Account account = PromptUI.promptAccount(customer);
		accountDao.addAccount(account);
	}
	
	public static void viewTransaction() {
		do {
			int choice=MenuUI.getTransactionSummaryType();
			switch(choice)
			{
				case 1:
					 Set<Transaction> transactions=transactionsService.getYearlyTransactions();
				     DisplayUI.printTransactions(transactions); 
					  break;	
				      
				case 2:   
					 Set<Transaction> transactions1=transactionsService.getQuarterlyTransactions();
				     DisplayUI.printTransactions(transactions1); 
					  break;	
					  
				case 3:   
					 Set<Transaction> transactions2=transactionsService.getMonthlyTransactions();
				     DisplayUI.printTransactions(transactions2); 
					 break;	
						      
				case 4:   
					 Set<Transaction> transactions3=transactionsService.getDailyTransactions();
				     DisplayUI.printTransactions(transactions3); 
					 break;	
					 
				case 5:
					 return;
			 }
		}while(MenuUI.getRepeatConfirmation());
	}
}
