package com.thebank.dao;

import java.util.Set;

import com.thebank.model.ServiceTracker;

public interface IServiceTrackerDao {

	public boolean addServiceTracker(ServiceTracker serviceTracker);
	public ServiceTracker getServiceFromServiceId(long serviceId);
	public Set<ServiceTracker> getAllServicesOfCustomer(long customerId);
	public Set<ServiceTracker> getAllServicesOfAccount(long accountId);
}
