package com.thebank.service;

import java.util.Set;

import com.thebank.dao.AccountDao;
import com.thebank.dao.IAccountDao;
import com.thebank.dao.ITransactionsDao;
import com.thebank.dao.TransactionsDao;
import com.thebank.exception.InvalidAmountException;
import com.thebank.model.Account;
import com.thebank.model.Transaction;

public class AccountService implements IAccountService{
	IAccountDao accountDao = new AccountDao();
	ITransactionsDao transactionsDao = new TransactionsDao();
	
	public AccountService() {

	}
	
	public AccountService(IAccountDao accountDao,ITransactionsDao transactionsDao) {
		this.accountDao = accountDao;
		this.transactionsDao = transactionsDao;
	}
	
	public boolean addAccount(Account account) throws InvalidAmountException {
		if(account==null)
		{
			throw new IllegalArgumentException();
		}
		else if(account.getAccountBalance()<5000)
		{
			throw new InvalidAmountException("Minimum account balance must be Rs. 5000. Try Again!");
		}
		return accountDao.addAccount(account);
	}

	@Override
	public Account getAccountFromAccountId(long accountId) {
		return accountDao.getAccountFromAccountId(accountId);
	}
	
	@Override
	public Set<Account> getAllAccountsOfCustomer(long customerId) {
		return accountDao.getAllAccountsOfCustomer(customerId);
	}


	@Override
	public Set<Account> getAllAccountsExceptGivenCustomer(long customerId) {
		return accountDao.getAllAccountsExceptGivenCustomer(customerId);
	}


	@Override
	public Set<Account> getAllAccountsExceptGivenAccountId(long customerId,long accountId) {
		return accountDao.getAllAccountsExceptGivenAccountId(customerId,accountId);
	}

	@Override
	public double getOpeningBalance(long accountNo) {
		// TODO Auto-generated method stub
		return accountDao.getOpeningBalance(accountNo);
	}

	@Override
	public double getCurrentBalanceForAccount(Account account) {
		double currentBalance=account.getAccountBalance();
		Set<Transaction> transactions=transactionsDao.getTransactionsForAccount(account.getAccountId());
		
		for(Transaction transaction:transactions)
		{
			if(transaction.getTransactionType()=='D')
			{
				currentBalance-=transaction.getAmount();
			}
			else if(transaction.getTransactionType()=='C')
			{
				currentBalance+=transaction.getAmount();
			}
		}
		return currentBalance;
	}
	

}
