package com.thebank.service;

import java.util.Set;

import com.thebank.dao.FundTransferDao;
import com.thebank.dao.IFundTransferDao;
import com.thebank.exception.InsufficientAccountBalanceException;
import com.thebank.model.Account;
import com.thebank.model.FundTransfer;

public class FundTransferService implements IFundTransferService{

	IFundTransferDao fundTransferDao = new FundTransferDao();
	IAccountService accountService = new AccountService();
	ITransactionsService transactionService=new TransactionsService();
	
	public FundTransferService() {
		
	}
	
	public FundTransferService(IFundTransferDao fundTransferDao,IAccountService accountService,ITransactionsService transactionService) {
		this.fundTransferDao=fundTransferDao;
		this.accountService = accountService;
		this.transactionService = transactionService;
	}

	@Override
	public boolean addFundTransfer(FundTransfer fundTransfer) throws InsufficientAccountBalanceException{
		if(fundTransfer==null) {
			throw new IllegalArgumentException();
		}
		
		Account account = accountService.getAccountFromAccountId(fundTransfer.getAccountId());
		if(account==null) {
			throw new IllegalArgumentException();
		}
		
		if(fundTransfer.getTransferAmount()>accountService.getCurrentBalanceForAccount(account))
		{
			throw new InsufficientAccountBalanceException("Your account balance is insufficient for this fund transfer.");
		}
		
		return fundTransferDao.addFundTransfer(fundTransfer);
	}

	@Override
	public FundTransfer getFundTransferFromFundTranferId(long fundTranferId) {
		if(fundTranferId<10000) {
			throw new IllegalArgumentException();
		}
		return fundTransferDao.getFundTransferFromFundTranferId(fundTranferId);
	}

	@Override
	public Set<FundTransfer> getAllFundTransfers() {
		return fundTransferDao.getAllFundTransfers();
	}

	@Override
	public Set<FundTransfer> getAllFundTransfersFromAccountId(long accountId) {
		return fundTransferDao.getAllFundTransfersFromAccountId(accountId);
	}
	
}
