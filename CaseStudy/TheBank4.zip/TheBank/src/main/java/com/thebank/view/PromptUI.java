package com.thebank.view;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.AccountType;
import com.thebank.model.Customer;
import com.thebank.model.Payee;
import com.thebank.model.ServiceTracker;
import com.thebank.model.User;
import com.thebank.service.AccountService;
import com.thebank.service.IAccountService;
import com.thebank.service.IUserService;
import com.thebank.service.UserService;
import com.thebank.util.Validator;

public class PromptUI {
	
	static Scanner scanner = new Scanner(System.in);
	static IUserService userService = new UserService();
	static IAccountService accountService = new AccountService();
	
	public static User promptLoginCredentialAndGetUser() {
		User user = new User();
		
		boolean success = false;
		String userName;
		do {
			System.out.println("Enter username");
			userName=scanner.next();
			success = userService.isUsersExists(userName);
		}while(!success);
		user.setUserName(userName);
		
		System.out.println("Do you remember your password:[Y/N]");
		String str=scanner.next();
		if(str.charAt(0)=='Y'||str.charAt(0)=='y') {
			do {
				System.out.println("Enter password: ");
				String loginPassword=scanner.next();
				
				user.setLoginPassword(loginPassword);
				success = userService.isValidUsers(user);
				if(!success) {
					System.out.println("Invalid password");
				}
			}while(!success);
		}else {
			user.setLoginPassword("sbq500#");
			userService.changeLoginPassword(user);
			System.out.println("Your new password is sbq500#");
			return promptLoginCredentialAndGetUser();
		}
		return user;
	}
	
	public static Customer promptCustomer() {
		Customer customer = new Customer();
		
		String customerName="";
		do{
			System.out.println("Enter name: ");
			customerName = scanner.next();
		}while(!Validator.validateName(customerName));
		customer.setCustomerName(customerName);
		
		String email="";
		do{
			System.out.println("Enter email: ");
			email = scanner.next();
		}while(!Validator.validateEmail(email));
		customer.setEmail(email);
		
		String mobile="";
		do{
			System.out.println("Enter mobile number: ");
			mobile = scanner.next();
		}while(!Validator.validateMobileNumber(mobile));
		customer.setMobileNo(mobile);

		System.out.println("Enter address: ");
		String address = scanner.next();
		customer.setAddress(address);
		
		String panCard="";
		do{
			System.out.println("Enter pan card number: ");
			panCard = scanner.next();
		}while(!Validator.validatePanCard(panCard));
		customer.setPancard(panCard);
		
		return customer;
	}
	
	public static Account promptAccount(Customer customer) {
		Account account = new Account();
		account.setCustomerId(customer.getCustomerId());
		
		System.out.println();
		System.out.println("Enter account details:");
		AccountType accountType = promptAccountType();
		account.setAccountType(accountType);
		
		account.setOpenDate(getDateFromUser("Enter account opening date[dd-mm-yyyy]:"));
		
		double balance = promptAmount("Enter opening balance");
		account.setAccountBalance(balance);
		
		System.out.println(account.toString());
		return account;
	}
	
	public static User promptUser(Customer customer) {
		User user = new User();
		user.setCustomerId(customer.getCustomerId());
		
		String loginPassword="";
		do{
			System.out.println("Enter login password: ");
			loginPassword = scanner.next();
		}while(!Validator.validatePassword(loginPassword));
		user.setLoginPassword(loginPassword);
		
		System.out.println("Enter secret question: ");
		String secretQuestion = scanner.next();
		user.setSecretQuestion(secretQuestion);

		System.out.println("Enter secret question answer: ");
		String secretQuestionAnswer = scanner.next();
		user.setSecretQuestionAnswer(secretQuestionAnswer);
		
		String transactionPassword="";
		do{
			System.out.println("Enter transaction password: ");
			transactionPassword = scanner.next();
		}while(!Validator.validatePassword(transactionPassword));
		user.setTransactionPassword(transactionPassword);
		
		user.setLockStatus('U');
		
		return user;
	}
	
	public static Payee promptPayee(Customer customer) {
		Set<Account> customerAccounts = accountService.getAllAccountsOfCustomer(customer.getCustomerId());
		Account account = PromptUI.getAccountChoice(customerAccounts);
		
		Payee payee = new Payee();
		payee.setAccountId(account.getAccountId());
		
		System.out.println("Select payee acount:");
		Set<Account> allAccounts = accountService.getAllAccountsExceptGivenCustomer(customer.getCustomerId());
		Account payeeAccount = PromptUI.getAccountChoice(allAccounts);
		payee.setPayeeAccountId(payeeAccount.getAccountId());
		
		String nickName="";
		do{
			System.out.println("Enter nick name: ");
			nickName = scanner.next();
		}while(!Validator.validateName(nickName));
		payee.setNickname(nickName);
		
		return payee;
	}
	
	public static AccountType promptAccountType() {
		AccountType[] accountTypes = AccountType.values();
		int count=0;
		for(AccountType accountType : accountTypes) {
			System.out.println((++count)+". "+accountType);
		}

		AccountType accountType=null;
		int accountTypeNo;
		while(accountType==null) {
			System.out.println("Enter account type number:");
			accountTypeNo = scanner.nextInt();
			accountType = getAccountTypeFromValue(accountTypeNo);
			if(accountType==null) {
				System.out.println("Invalid Account type");
			}
		}
		return accountType;
	}
	
	public static AccountType getAccountTypeFromValue(int value) {
		switch (value) {
			case 1:
				return AccountType.SAVINGS;
			case 2:
				return AccountType.CURRENT;
			case 3:
				return AccountType.RD;
			case 4:
				return AccountType.FD;
			default:
				return null;
		}
	}
	
	private static LocalDate getDateFromUser(String message) {
		String date="";
		while(!Validator.validateDate(date)) {
			System.out.println(message);
			date = scanner.next();
		}
		String dateParts[] = date.split("-");
		return LocalDate.of(Integer.parseInt(dateParts[2]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[0]));
	}
	
	public static String promptMobileNumber() {
		String mobile="";
		do{
			System.out.println("Enter mobile number: ");
			mobile = scanner.next();
		}while(!Validator.validateMobileNumber(mobile));
		return mobile;
	}
	
	public static double promptAmount(String message) {
		double amount=0;
		do{
			System.out.println(message);
			amount = scanner.nextDouble();
			if(amount<=0) {
				System.out.println("Invalid amount");
			}
		}while(amount<=0);
		return amount;
	}
	
	public static Account getAccountChoice(Set<Account> accounts) {
		if(accounts.size()<=0) {
			System.out.println("No accounts available");
			return null;
		}
		System.out.println();
		System.out.println("Select account from following:");
		
		for(Account account:accounts) {
			System.out.println(account.getAccountId()+" "+account.getAccountType());
		}
		
		Account account=null;
		while(account==null) {
			System.out.println("Choose account id: ");
			long accountId = scanner.nextLong();
			account = getAccountFromAccountId(accounts, accountId);
			if(account==null) {
				System.out.println("Invalid account id");
			}
		}
		return account;
	}
	
	private static Account getAccountFromAccountId(Set<Account> accounts,long accountId) {
		for(Account account:accounts) {
			if(account.getAccountId()==accountId) {
				return account;
			}
		}
		return null;
	}
	
	public static ServiceTracker getServiceChoice(Set<ServiceTracker> serviceTrackers) {
		if(serviceTrackers.size()<=0) {
			System.out.println("No services available");
			return null;
		}
		System.out.println();
		System.out.println("Select service from following:");
		
		for(ServiceTracker serviceTracker:serviceTrackers) {
			System.out.println(serviceTracker.getServiceId()+" "+serviceTracker.getServiceDescription());
		}
		
		ServiceTracker serviceTracker=null;
		while(serviceTracker==null) {
			System.out.println("Choose service id: ");
			long serviceTrackerId = scanner.nextLong();
			serviceTracker = getServiceFromServiceId(serviceTrackers, serviceTrackerId);
			if(serviceTracker==null) {
				System.out.println("Invalid service id");
			}
		}
		return serviceTracker;
	}
	
	private static ServiceTracker getServiceFromServiceId(Set<ServiceTracker> serviceTrackers,long serviceTrackerId) {
		for(ServiceTracker serviceTracker:serviceTrackers) {
			if(serviceTracker.getServiceId()==serviceTrackerId) {
				return serviceTracker;
			}
		}
		return null;
	}
	
	public static Payee getPayeeChoice(Set<Payee> payees) {
		if(payees.size()<=0) {
			System.out.println("No payees available");
			return null;
		}
		System.out.println();
		System.out.println("Select account from following:");
		
		for(Payee payee:payees) {
			System.out.println(payee.getPayeeAccountId()+" "+payee.getNickname());
		}
		
		Payee payee=null;
		while(payee==null) {
			System.out.println("Choose account id: ");
			long payeeId = scanner.nextLong();
			payee = getPayeeFromPayeeId(payees, payeeId);
			if(payee==null) {
				System.out.println("Invalid account id");
			}
		}
		return payee;
	}
	
	private static Payee getPayeeFromPayeeId(Set<Payee> payees,long accountId) {
		for(Payee payee:payees) {
			if(payee.getAccountId()==accountId) {
				return payee;
			}
		}
		return null;
	}
	
}
