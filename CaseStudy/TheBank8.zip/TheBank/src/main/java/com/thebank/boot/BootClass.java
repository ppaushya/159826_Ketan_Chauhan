package com.thebank.boot;

import com.thebank.view.MenuUI;
import com.thebank.view.ServiceUI;
import com.thebank.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
				
		do {
			int choice = MenuUI.getTaskType();
			switch(choice) {
				case 1:
					UserInteraction.doCustomerTasks();
					break;
				case 2:
					UserInteraction.doAdminTasks();
					break;
				case 3:
					ServiceUI.signUp();
					break;
				case 4:
					System.out.println("Thank you!");
					System.exit(0);
					break;
			}
		}while(MenuUI.getRepeatConfirmation());
		System.out.println("Thank you!");
	}

}
