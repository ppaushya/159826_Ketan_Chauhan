package com.thebank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

import com.thebank.model.Transaction;

public class TransactionsDao implements ITransactionsDao{

	public boolean addTransaction(Transaction transaction) {
		
		String mysql = "insert into transactions(transactionDescription, dateOfTransaction, transactionType, transactionAmount, accountId) values(?,?,?,?,?)";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			
			PreparedStatement statement=conn.prepareStatement(mysql);
			
			statement.setString(1, transaction.getDescription());
			statement.setDate(2, Date.valueOf(transaction.getTransactionDate()));
			statement.setString(3,String.valueOf(transaction.getTransactionType()));
			statement.setDouble(4, transaction.getAmount());
			statement.setLong(5, transaction.getAccountId());
			
			int count=statement.executeUpdate();
			if(count>0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}


	@Override
	public Transaction getTransactionFormTransactionId(long transactionId) {
		String mysql = "select * from transactions where transactionId=?";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, transactionId);
			
			ResultSet resultSet= pst.executeQuery();
			
			if(resultSet.next()) {
				Transaction transaction=new Transaction();
			
				transaction.setTransactionId(transactionId);
				transaction.setDescription(resultSet.getString("transactionDescription"));
				transaction.setTransactionDate(resultSet.getDate("dateOfTransaction").toLocalDate());
				transaction.setTransactionType(resultSet.getString("transactionType").charAt(0));
				transaction.setAmount(resultSet.getDouble("transactionAmount"));
				transaction.setAccountId(resultSet.getLong("accountId"));
				
				return transaction;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return null;
	}
	
	@Override
	public Set<Transaction> getAllTransaction() {
		
		String mysql = "select * from transactions";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getTransactionsForAccount(long accountId) {
		String mysql = "select * from transactions where accountId = ?";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, accountId);
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}

	@Override
	public Set<Transaction> getTransactionsForCustomer(long customerId) {
		
		String mysql = "select * from transactions"
				+ " join accountMaster using(accountId)"
				+ " where customerId = ?";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Set<Transaction> getLastNTransactionsForAccount(long accountId, int count) {
		System.out.println(accountId);
		System.out.println(count);
		String mysql = "select * from transactions where accountId = ? order by dateOfTransaction limit ?";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, accountId);
			pst.setInt(2, count);
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getDailyTransactions() {
		String mysql = "select * from transactions where dateOfTransaction = ?";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setDate(1, Date.valueOf(LocalDate.now()));
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getMonthlyTransactions() {
		String mysql = "select * from transactions"
				+ " where month(dateOfTransaction) = month(?)";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setDate(1, Date.valueOf(LocalDate.now()));
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getQuarterlyTransactions() {
		String mysql = "select * from transactions"
				+ " where quarter(dateOfTransaction) = quarter(?)";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setDate(1, Date.valueOf(LocalDate.now()));
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getYearlyTransactions() {
		String mysql = "select * from transactions"
				+ " where year(dateOfTransaction) = year(?)";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setDate(1, Date.valueOf(LocalDate.now()));
			
			ResultSet resultSet= pst.executeQuery();
			
			return getTransactionsFromResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private Set<Transaction> getTransactionsFromResultSet(ResultSet resultSet) throws SQLException {
		Set<Transaction> transactionSet = new LinkedHashSet<>();
		
		while(resultSet.next()) {
			Transaction transaction=new Transaction();
		
			transaction.setTransactionId(resultSet.getLong("transactionId"));
			transaction.setDescription(resultSet.getString("transactionDescription"));
			transaction.setTransactionDate(resultSet.getDate("dateOfTransaction").toLocalDate());
			transaction.setTransactionType(resultSet.getString("transactionType").charAt(0));
			transaction.setAmount(resultSet.getDouble("transactionAmount"));
			transaction.setAccountId(resultSet.getLong("accountId"));
			
			transactionSet.add(transaction);
		}
		
		return transactionSet;
	}
}
