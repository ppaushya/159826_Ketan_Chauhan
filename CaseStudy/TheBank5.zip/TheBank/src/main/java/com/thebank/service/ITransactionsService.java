package com.thebank.service;

import java.util.Set;

import com.thebank.model.Transaction;

public interface ITransactionsService {

	public boolean addTransaction();
	public boolean getTransaction();
	public Set<Transaction> getAllTransaction();
	public Set<Transaction> getTransactionsForAccount(long accountId);
	public Set<Transaction> getTransactionsForCustomer(long customerId);
	public Set<Transaction> getLastNTransactionsForAccount(long customerId,int count);
	
	public Set<Transaction> getDailyTransactions();
	public Set<Transaction> getMonthlyTransactions();
	public Set<Transaction> getQuarterlyTransactions();
	public Set<Transaction> getYearlyTransactions();
}
