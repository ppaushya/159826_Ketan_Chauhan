package com.thebank.view;

import java.util.Set;

import com.thebank.model.Customer;
import com.thebank.model.Transaction;
import com.thebank.service.CustomerService;
import com.thebank.service.ICustomerService;
import com.thebank.service.ITransactionsService;
import com.thebank.service.TransactionsService;

public class AdminServiceUI {
static ICustomerService customerService=new CustomerService();
static ITransactionsService transactionsService=new TransactionsService();
	public static void createNewAccount() {
		 Customer customer=PromptUI.promptCustomer();
		 customerService.addCustomer(customer); 
		
	}
	
	public static void viewTransaction() {
		int choice=MenuUI.getTransaction();
		 switch(choice)
		 {
		 case 1:
			 Set<Transaction> transactions=transactionsService.getYearlyTransactions();
		     DisplayUI.printTransactions(transactions); 
			  break;	
		      
		 case 2:   
			 Set<Transaction> transactions1=transactionsService.getQuarterlyTransactions();
		     DisplayUI.printTransactions(transactions1); 
			  break;	
			  
		   case 3:   
					 Set<Transaction> transactions2=transactionsService.getMonthlyTransactions();
				     DisplayUI.printTransactions(transactions2); 
					  break;	
				      
			 case 4:   
				 Set<Transaction> transactions3=transactionsService.getDailyTransactions();
			     DisplayUI.printTransactions(transactions3); 
				  break;	
				  
		 
		 }
		 
		
	}
}
