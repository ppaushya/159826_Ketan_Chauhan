package com.thebank.boot;

import com.thebank.view.MenuUI;
import com.thebank.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
				
		do {
			int choice = MenuUI.getTaskType();
			switch(choice) {
				case 1:
					UserInteraction.doCustomerTasks();
					break;
				case 2:
					UserInteraction.doAdminTasks();
			}
		}while(MenuUI.getRepeatConfirmation());

	}

}
