package com.thebank.dao;

import java.util.Set;

import com.thebank.model.ServiceTracker;

public interface IServiceTrackerDao {

	public boolean addService();
	public Set<ServiceTracker> getService(int accountId);
}
