package com.thebank.service;

public class ServiceTrackerService implements IServiceTrackerService{

	public boolean addService() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean getService() {
		// TODO Auto-generated method stub
		return false;
	}

}
