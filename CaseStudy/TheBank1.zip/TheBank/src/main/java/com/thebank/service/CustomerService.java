package com.thebank.service;

public class CustomerService implements ICustomerService{

	public boolean addCustomer() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean getCustomer() {
		// TODO Auto-generated method stub
		return false;
	}

}
