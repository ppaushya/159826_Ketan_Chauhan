package com.thebank.service;

import java.util.Set;

import com.thebank.dao.IUserDao;
import com.thebank.dao.UserDao;
import com.thebank.model.User;

public class UserService implements IUserService{
	IUserDao userDao = new UserDao();
	
	@Override
	public boolean addUser(User user) {
		return userDao.addUser(user);
	}

	@Override
	public User getUserFromUserId(long userId) {
		return userDao.getUserFromUserId(userId);
	}

	@Override
	public Set<User> getAllUsers() {
		return userDao.getAllUsers();
	}

	@Override
	public boolean changeLoginPassword(User user) {
		return userDao.changeLoginPassword(user);
	}

	@Override
	public boolean changeTransactionPassword(User user) {
		return userDao.changeLockStatus(user);
	}

	@Override
	public boolean changeLockStatus(User user) {
		return userDao.changeLockStatus(user);
	}

}
