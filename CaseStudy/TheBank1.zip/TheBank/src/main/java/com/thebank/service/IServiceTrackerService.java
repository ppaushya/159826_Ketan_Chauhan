package com.thebank.service;

public interface IServiceTrackerService {

	public boolean addService();
	public boolean getService();
}
