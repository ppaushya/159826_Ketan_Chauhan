package com.thebank.service;

public class AccountService implements IAccountService{

	public boolean addAccount() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean getAccount() {
		// TODO Auto-generated method stub
		return false;
	}

}
