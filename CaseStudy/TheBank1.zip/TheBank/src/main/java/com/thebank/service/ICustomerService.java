package com.thebank.service;

public interface ICustomerService {

	public boolean addCustomer();
	public boolean getCustomer();
}
