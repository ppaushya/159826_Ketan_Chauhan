package com.thebank.service;

import static org.junit.Assert.*;

import java.time.LocalDate;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.thebank.dao.IAccountDao;
import com.thebank.exception.InvalidAmountException;
import com.thebank.model.Account;
import com.thebank.model.AccountType;

public class AccountServiceTest {

	
	@Mock
	IAccountDao accountDao;

	static IAccountService accountServices;
	
@Before
public void init()	{
	MockitoAnnotations.initMocks(this);
	accountServices=new AccountService(accountDao);
}
	@Test(expected=IllegalArgumentException.class)
public void test_null_account_creation() throws InvalidAmountException {
		Account account=new Account();
		
		account=null;
		accountServices.addAccount(account);
		
	}

	@Test(expected=InvalidAmountException.class)
public void test_invalid_amount_account() throws InvalidAmountException {
		Account account=new Account(101, AccountType.SAVINGS, LocalDate.now(),1000);
		
		accountServices.addAccount(account);
		
	}


	@Test
	public void test_createAccount_successful() throws InvalidAmountException	{
		Account account=new Account(101, AccountType.SAVINGS, LocalDate.now(),10000);
		
		Mockito.when(accountDao.addAccount(account)).thenReturn(true);
		accountServices.addAccount(account);
		
		Mockito.verify(accountDao).addAccount(account);
		
	}

}
