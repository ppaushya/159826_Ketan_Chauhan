package com.thebank.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.thebank.dao.ITransactionsDao;
import com.thebank.dao.IUserDao;
import com.thebank.model.Transaction;
import com.thebank.model.User;

public class UserServiceTest {

	@Mock
	IUserDao userDao;

	static IUserService userServices;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		userServices = new UserService(userDao);
	}

	@Test(expected = IllegalArgumentException.class)
	public void test_null_user_creation() {
	User user=new User();
	user = null;
	userServices.addUser(user);

	}

	@Test
	public void test_user_successful() {
		User user=new User();
		Mockito.when(userDao.addUser(user)).thenReturn(true);
		userServices.addUser(user);
		Mockito.verify(userDao).addUser(user);

	}
}
