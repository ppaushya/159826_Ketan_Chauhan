package com.thebank.service;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.thebank.dao.IPayeeDao;

import com.thebank.model.Payee;

public class PayeeServiceTest {

	@Mock
	IPayeeDao payeeDao;

	static IPayeeService payeeServices;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		payeeServices = new PayeeService(payeeDao);
	}

	@Test(expected = IllegalArgumentException.class)
	public void test_null_payee_creation() {
		Payee payee = new Payee();
		payee = null;
		payeeServices.addPayee(payee);

	}

	@Test
	public void test_createPayee_successful() {
		Payee payee = new Payee(123, 565, "mohu");

		Mockito.when(payeeDao.addPayee(payee)).thenReturn(true);
		payeeServices.addPayee(payee);

		Mockito.verify(payeeDao).addPayee(payee);

	}

}
