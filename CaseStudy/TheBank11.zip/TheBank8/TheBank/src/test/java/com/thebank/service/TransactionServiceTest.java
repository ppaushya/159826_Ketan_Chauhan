package com.thebank.service;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;

import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


import com.thebank.dao.ITransactionsDao;

import com.thebank.model.Transaction;

public class TransactionServiceTest {


	@Mock
	ITransactionsDao transactionDao;

	static ITransactionsService transactionServices;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		transactionServices = new TransactionsService(transactionDao);
	}

	@Test(expected = IllegalArgumentException.class)
	public void test_null_transactions_creation() {
	 Transaction transaction= new Transaction();
	 transaction = null;
	 transactionServices.addTransaction(transaction);

	}

	@Test
	public void test_transaction_successful() {
		 Transaction transaction= new Transaction();
		Mockito.when(transactionDao.addTransaction(transaction)).thenReturn(true);
		 transactionServices.addTransaction(transaction);
		Mockito.verify(transactionDao).addTransaction(transaction);

	}
}
