package com.thebank.view;

import java.util.Scanner;

import com.thebank.exception.InsufficientAccountBalanceException;
import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.User;
import com.thebank.service.AccountService;
import com.thebank.service.CustomerService;
import com.thebank.service.IAccountService;
import com.thebank.service.ICustomerService;
import com.thebank.service.IServiceTrackerService;
import com.thebank.service.IUserService;
import com.thebank.service.ServiceTrackerService;
import com.thebank.service.UserService;

public class UserInteraction {

	static Scanner scanner = new Scanner(System.in);
	static IUserService userService = new UserService();
	static ICustomerService customerService = new CustomerService();
	static IAccountService accountService = new AccountService();
	static IServiceTrackerService serviceTrackerService = new ServiceTrackerService();

	public static void doCustomerTasks() {
		
		User user = PromptUI.promptLoginCredentialAndGetUser();
		if(user==null) {
			return;
		}
		Customer customer = customerService.getCustomerFromCustomerId(user.getCustomerId());
		if(customer==null) {
			return;
		}
		
		do {
			int choice = MenuUI.getTaskChoiceOfCustomer(customer.getCustomerName());
			
			switch(choice)
		    {
			    case 1:
			    	ServiceUI.showMiniOrDetailedStatement(customer);
			    	break;
			    	
			    case 2:
			    	ServiceUI.changeAddressOrMobile(customer);
			    	break;
			    	
			    case 3:
			    	Account account = PromptUI.getAccountChoice(
			    			accountService.getAllAccountsOfCustomer(customer.getCustomerId()));
			    	if(account!=null) {
				    	serviceTrackerService.addChequebookRequest(account);
			    	}
			    	break;
			    	
			    case 4:
			    	ServiceUI.trackServiceRequest(customer);
			    	break;
			    	
			    case 5:
			    	ServiceUI.doFundTransfer(customer);
			    	break;
			    	
			    case 6:
			    	ServiceUI.changePassword(user);
			    	break;
			    	
			    case 7:
			    	ServiceUI.printCurrentBalance(customer);
			    	break;
					    	
			    case 8:
			    	return;
		    }
		}while(MenuUI.getRepeatConfirmation());
		
	}
	
	public static void doAdminTasks() {
		do {
			int choice = MenuUI.getTaskChoiceOfAdmin();
			
			switch(choice)
		    {
			    case 1:
			    	AdminServiceUI.createNewAccount();
			    	break;
			    	
			    case 2:
			    	AdminServiceUI.viewTransaction();
			    	break;
			    	
		    	case 3:
		    		return;
		    }
		}while(MenuUI.getRepeatConfirmation());
	}
	
}
