package com.thebank.service;

import java.util.Set;

import com.thebank.model.Customer;

public interface ICustomerService {

	public boolean addCustomer(Customer customer);
	public Customer getCustomerFromCustomerId(long customerId);
	public Set<Customer> getAllCustomers();
	public boolean changeCustomerAddress(Customer customer);
	public boolean changeCustomerMobileNo(Customer customer);
	
	public long getLastAddedCustomerId();
	public boolean isEmailExists(String email);
	public boolean isPanCardExists(String panCard);
}
