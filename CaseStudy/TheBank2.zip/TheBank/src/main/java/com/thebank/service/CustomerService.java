package com.thebank.service;

import com.thebank.model.Customer;

public class CustomerService implements ICustomerService{

	public boolean addCustomer() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean getCustomer() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomerFromCustomerId(long customerId) {
		// TODO Auto-generated method stub
		return null;
	}

}
