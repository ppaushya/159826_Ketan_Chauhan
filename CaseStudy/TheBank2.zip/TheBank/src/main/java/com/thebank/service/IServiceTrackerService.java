package com.thebank.service;

import java.util.Set;

import com.thebank.model.ServiceTracker;

public interface IServiceTrackerService {

	public boolean addService();
	public Set<ServiceTracker> getService();
	public boolean addChequebookRequest();
}
