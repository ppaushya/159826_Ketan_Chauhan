package com.thebank.view;

import java.util.Scanner;

import com.thebank.model.Customer;
import com.thebank.model.User;
import com.thebank.service.IUserService;
import com.thebank.service.UserService;

public class ServiceUI {

	static Scanner scanner = new Scanner(System.in);
	static IUserService userService = new UserService();
	
	public static void changeAddressAndMobile(Customer customer) {
		System.out.println("Current address is : -");
    	System.out.println(customer.getAddress());
    	System.out.println("Current Mobile Number is : -");
    	System.out.println(customer.getEmail());
    	
    	System.out.println("Enter new address:");
    	String newAddress = scanner.next();
    	
    	String newMobile = PromptUI.promptMobileNumber();
    	
    	//TODO change
    	//customerService.changeAddress(newAddress);
    	//customerService.changeMobileNo(newMobile);
	}
	
	public static void changePassword(User user) {
		boolean success = false;
    	do{
    		System.out.println("Enter new password");
			String pwd=scanner.next();
		   	System.out.println("Confirm password");
		   	String confirmPwd=scanner.next();
		   	if(pwd.equals(confirmPwd)) {
		   		user.setLoginPassword(pwd);
	    		success = userService.changeLoginPassword(user);
	    		if(success) {
		    		break;
	    		}
		   	}
		   		
	    }while(!success);
	}
	
	public static void doTransactions() {
		/*Transactions transaction=new Transactions();
 	   List<Account> accounts= customer.getAccounts();						    	   								   
		   UserInteraction.printAccounts(accounts);
		   System.out.println("Enter accountId to transfer funds from");
		   long fromAccountId=scanner.nextInt();
		   
          Account account=userService.ifAccountFound(customer,fromAccountId);
           if(account==null)
          {
              System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
              break;
          }
           System.out.println("Enter accountId to which you want to transfer funds");
           long toAccountId=scanner.nextInt();
         
          
          Account account=userService.ifAccountFoundTo(toAccountId);
           if(account==null)
          {
              System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
              break;
          }
          transaction.setFromAccount(account);
          transaction.setTransactionType("Fund Transfer");
          
          System.out.println("Enter amount to transfer");
          amount=scanner.nextDouble();*/
	}
}
