package com.thebank.service;

import com.thebank.model.Customer;

public interface ICustomerService {

	public boolean addCustomer();
	public boolean getCustomer();
	public Customer getCustomerFromCustomerId(long customerId);
}
