package com.thebank.service;

import java.util.Set;

import com.thebank.model.ServiceTracker;

public class ServiceTrackerService implements IServiceTrackerService{

	public boolean addService() {
		// TODO Auto-generated method stub
		return false;
	}

	public Set<ServiceTracker> getService() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addChequebookRequest() {
		// TODO Auto-generated method stub
		return false;
	}

}
