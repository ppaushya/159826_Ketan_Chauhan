package com.thebank.view;

import java.util.Scanner;

import com.thebank.model.User;
import com.thebank.service.IUserService;
import com.thebank.service.UserService;
import com.thebank.util.Validator;

public class PromptUI {
	
	static Scanner scanner = new Scanner(System.in);
	static IUserService userService = new UserService();
	
	public static String promptMobileNumber() {
		String mobile="";
		while(!Validator.validateMobileNumber(mobile)) {
			System.out.println("Enter mobile number: ");
			mobile = scanner.next();
		}
		return mobile;
	}

	public static User promptLoginCredentialAndGetUser() {
		User user = new User();
		
		boolean success = false;
		String userName;
		do {
			System.out.println("Enter username");
			userName=scanner.next();
			success = userService.isUsersExists(userName);
		}while(!success);
		user.setUserName(userName);
		
		System.out.println("Do you remember your password:[Y/N]");
		String str=scanner.next();
		if(str.charAt(0)=='Y'||str.charAt(0)=='y') {
			do {
				System.out.println("Enter password: ");
				String loginPassword=scanner.next();
				
				user.setLoginPassword(loginPassword);
				success = userService.isValidUsers(user);
				if(!success) {
					System.out.println("Invalid password");
				}
			}while(!success);
		}else {
			user.setLoginPassword("sbq500#");
			userService.changeLoginPassword(user);
			System.out.println("Your new password is sbq500#");
			return promptLoginCredentialAndGetUser();
		}
		return user;
	}
}
