package com.thebank.service;

public class TransactionsService implements ITransactionsService{

	public boolean addTransaction() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean getTransaction() {
		// TODO Auto-generated method stub
		return false;
	}

}
