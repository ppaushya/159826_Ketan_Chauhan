package com.thebank.view;

import java.util.Scanner;
import java.util.Set;

import com.thebank.model.Customer;
import com.thebank.model.ServiceTracker;
import com.thebank.model.User;
import com.thebank.service.CustomerService;
import com.thebank.service.ICustomerService;
import com.thebank.service.IServiceTrackerService;
import com.thebank.service.IUserService;
import com.thebank.service.ServiceTrackerService;
import com.thebank.service.UserService;

public class UserInteraction {

	Scanner scanner = new Scanner(System.in);
	IUserService userService = new UserService();
	ICustomerService customerService = new CustomerService();
	IServiceTrackerService serviceTrackerService = new ServiceTrackerService();

	public void doCustomerTasks() {
		
		User user = PromptUI.promptLoginCredentialAndGetUser();
		Customer customer = customerService.getCustomerFromCustomerId(user.getCustomerId());
		
		int choice = MenuUI.getTaskChoiceOfCustomer(customer.getCustomerName());
		
		switch(choice)
	    {
		    case 1:
		    	break;
		    	
		    case 2:
		    	ServiceUI.changeAddressAndMobile(customer);
		    	break;
		    	
		    case 3:
		    	serviceTrackerService.addChequebookRequest();
		    	break;
		    	
		    case 4:
		    	Set<ServiceTracker> serviceTrackers = serviceTrackerService.getService();
		    	DisplayUI.printServiceTrackers(serviceTrackers);
		    	break;
		    	
		    case 5:
		    	ServiceUI.doTransactions();
		    	break;
				    	
		    case 6:
		    	ServiceUI.changePassword(user);
		    	break;
	    }
	}
	
	public void doAdminTasks() {
		int choice = MenuUI.getTaskChoiceOfAdmin();
		
		switch(choice)
	    {
		    case 1:
		    	break;
		    	
		    case 2:
		    	break;
	    }
	}
	
}
