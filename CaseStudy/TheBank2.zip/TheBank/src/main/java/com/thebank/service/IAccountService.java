package com.thebank.service;

public interface IAccountService {

	public boolean addAccount();
	public boolean getAccount();
}
