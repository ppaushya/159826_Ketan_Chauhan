package com.thebank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.thebank.model.Transactions;

public class TransactionsDao implements ITransactionsDao{

	public boolean addTransaction() {
		
		String mysql = "insert into transactions(transactionDescription, dateOfTransaction, transactionType,"
				+ "transactionAmount, accountId) values(?,?,?,?,?)";
		Transactions transactions=new Transactions();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			
			PreparedStatement statement=conn.prepareStatement(mysql);
			
			statement.setString(1, transactions.getDescription());
			statement.setDate(2, Date.valueOf(transactions.getTransactionDate()));
			statement.setString(3,String.valueOf(transactions.getTransactionType()));
			statement.setDouble(4, transactions.getAmount());
			statement.setLong(5, transactions.getAccountId());
			
			int count=statement.executeUpdate();
			if(count>0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public Set<Transactions> getAllTransaction() {
		
		String mysql = "select * from transactions";
		Transactions transactions=new Transactions();
		Set<Transactions> transactionSet = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
			
				transactions.setDescription(resultSet.getString(2));
				transactions.setTransactionDate(resultSet.getDate(3).toLocalDate());
				transactions.setTransactionType(resultSet.getString(4).charAt(0));
				transactions.setAmount(resultSet.getDouble(5));
				transactions.setAccountId(resultSet.getLong(6));
				
				transactionSet.add(transactions);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return transactionSet;
	}

	@Override
	public Set<Transactions> getTransactionsForAccount(long accountId) {

		String mysql = "select * from transactions where accountId = ?";
		Transactions transactions=new Transactions();
		Set<Transactions> transactionSet = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, accountId);
			
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
			
				transactions.setDescription(resultSet.getString(2));
				transactions.setTransactionDate(resultSet.getDate(3).toLocalDate());
				transactions.setTransactionType(resultSet.getString(4).charAt(0));
				transactions.setAmount(resultSet.getDouble(5));
				transactions.setAccountId(resultSet.getLong(6));
				
				transactionSet.add(transactions);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return transactionSet;
		
	}

	@Override
	public Set<Transactions> getTransactionsForCustomer(long customerId) {
		
		String mysql = "select * from transactions where accountId = ?";
		Transactions transactions=new Transactions();
		Set<Transactions> transactionSet = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
			
				transactions.setDescription(resultSet.getString(2));
				transactions.setTransactionDate(resultSet.getDate(3).toLocalDate());
				transactions.setTransactionType(resultSet.getString(4).charAt(0));
				transactions.setAmount(resultSet.getDouble(5));
				transactions.setAccountId(resultSet.getLong(6));
				
				transactionSet.add(transactions);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return transactionSet;
	}
}
