package com.thebank.service;

public interface ITransactionsService {

	public boolean addTransaction();
	public boolean getTransaction();
}
