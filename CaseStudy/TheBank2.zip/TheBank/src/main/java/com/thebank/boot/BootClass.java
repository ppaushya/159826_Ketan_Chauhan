package com.thebank.boot;

import java.util.Scanner;

import com.thebank.view.MenuUI;
import com.thebank.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		UserInteraction ui=new UserInteraction();
		
		do {
			System.out.println("Welcome to Online Banking System");
			System.out.println();
			System.out.println("Login as:\n1.Account Holder\n2.Bank Administrator");
			int option=scanner.nextInt();
			switch(option) {
			case 1:
				ui.doCustomerTasks();
			}
			
		}while(MenuUI.getRepeatConfirmation());

	}

}
