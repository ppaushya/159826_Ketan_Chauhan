package com.thebank.service;

import java.util.Set;

import com.thebank.model.Account;

public interface IAccountService {

	public boolean addAccount(Account account);
	public Account getAccountFromAccountId(long accountId);
	public Set<Account> getAllAccountsOfCustomer(long customerId);
	public Set<Account> getAllAccountsExceptGivenAccountId(long customerId,long accountId);
	public Set<Account> getAllAccountsExceptGivenCustomer(long customerId);
}
