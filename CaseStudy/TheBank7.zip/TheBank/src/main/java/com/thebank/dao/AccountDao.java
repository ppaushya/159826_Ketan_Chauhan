package com.thebank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.AccountType;

public class AccountDao implements IAccountDao{

	public boolean addAccount(Account account) {
		
		String mysql = "insert into accountmaster(customerId, accountType, accountBalance, openDate) values(?,?,?,?)";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			
			PreparedStatement statement=conn.prepareStatement(mysql);
			statement.setLong(1, account.getCustomerId());
			statement.setString(2, account.getAccountType().toString());
			statement.setDouble(3, account.getAccountBalance());
			statement.setDate(4, Date.valueOf(account.getOpenDate()));
			
			int count=statement.executeUpdate();
			if(count>0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public Set<Account> getAllAccountsOfCustomer(long customerId) {
		
		String mysql = "select * from accountmaster where customerId = ?";
		Set<Account> accountSet = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				Account account=new Account();
				
				account.setAccountBalance(resultSet.getDouble(4));
				account.setAccountId(resultSet.getLong(1));
				account.setCustomerId(customerId);
				account.setAccountType(AccountType.valueOf(resultSet.getString(3)));
				account.setOpenDate(resultSet.getDate(5).toLocalDate());
				
				accountSet.add(account);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return accountSet;
	}

	@Override
	public Account getAccountFromAccountId(long accountId) {
		String mysql = "select * from accountmaster where accountId = ?";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, accountId);
			ResultSet resultSet= pst.executeQuery();
			
			if(resultSet.next()) {
				Account account=new Account();
				account.setAccountBalance(resultSet.getDouble(4));
				account.setAccountId(accountId);
				account.setCustomerId(resultSet.getLong(2));
				account.setAccountType(AccountType.valueOf(resultSet.getString(3)));
				account.setOpenDate(resultSet.getDate(5).toLocalDate());
				
				return account;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return null;
	}

	@Override
	public Set<Account> getAllAccountsExceptGivenAccountId(long customerId,long accountId) {
		String mysql = "select * from accountmaster where"
				+ " customerId = ? and accountId != ?";
		Set<Account> accountSet = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			pst.setLong(2, accountId);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				Account account=new Account();
				
				account.setAccountBalance(resultSet.getDouble(4));
				account.setAccountId(resultSet.getLong(1));
				account.setCustomerId(resultSet.getLong(2));
				account.setAccountType(AccountType.valueOf(resultSet.getString(3)));
				account.setOpenDate(resultSet.getDate(5).toLocalDate());
				
				accountSet.add(account);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return accountSet;
	}

	@Override
	public Set<Account> getAllAccountsExceptGivenCustomer(long customerId) {
		String mysql = "select * from accountmaster where customerId != ?";
		Set<Account> accountSet = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				Account account=new Account();
				
				account.setAccountBalance(resultSet.getDouble(4));
				account.setAccountId(resultSet.getLong(1));
				account.setCustomerId(resultSet.getLong(2));
				account.setAccountType(AccountType.valueOf(resultSet.getString(3)));
				account.setOpenDate(resultSet.getDate(5).toLocalDate());
				
				accountSet.add(account);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return accountSet;
	}
}
