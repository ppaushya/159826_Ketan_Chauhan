package com.thebank.service;

import java.util.Set;

import com.thebank.dao.AccountDao;
import com.thebank.dao.IAccountDao;
import com.thebank.model.Account;

public class AccountService implements IAccountService{
	IAccountDao accountDao = new AccountDao();
	
	public boolean addAccount(Account account) {
		return accountDao.addAccount(account);
	}

	@Override
	public Account getAccountFromAccountId(long accountId) {
		return accountDao.getAccountFromAccountId(accountId);
	}
	
	@Override
	public Set<Account> getAllAccountsOfCustomer(long customerId) {
		return accountDao.getAllAccountsOfCustomer(customerId);
	}


	@Override
	public Set<Account> getAllAccountsExceptGivenCustomer(long customerId) {
		return accountDao.getAllAccountsExceptGivenCustomer(customerId);
	}


	@Override
	public Set<Account> getAllAccountsExceptGivenAccountId(long customerId,long accountId) {
		return accountDao.getAllAccountsExceptGivenAccountId(customerId,accountId);
	}


}
