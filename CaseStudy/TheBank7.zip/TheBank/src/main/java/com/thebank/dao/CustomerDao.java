package com.thebank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.thebank.model.Customer;

public class CustomerDao implements ICustomerDao{

	public boolean addCustomer(Customer customer) {
		
		String mysql = "insert into customer(customerName, email, mobileNo, address, panCard) values(?,?,?,?,?)";
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			
			PreparedStatement statement=conn.prepareStatement(mysql);
			statement.setString(1, customer.getCustomerName());
			statement.setString(2, customer.getEmail());
			statement.setString(3, customer.getMobileNo());
			statement.setString(4, customer.getAddress());
			statement.setString(5, customer.getPancard());
			
			int count=statement.executeUpdate();
			if(count>0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	public Customer getCustomerFromCustomerId(long customerId) {
		
		String mysql = "select * from customer where customerId = ?";
		Customer customer=new Customer();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			pst.setLong(1, customerId);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				
				customer.setCustomerId(customerId);
				customer.setCustomerName(resultSet.getString(2));
				customer.setEmail(resultSet.getString(3));
				customer.setMobileNo(resultSet.getString(4));
				customer.setAddress(resultSet.getString(5));
				customer.setPancard(resultSet.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return customer;	
	}
	

	@Override
	public Set<Customer> getAllCustomers() {
		String mysql = "select * from customer";
		Set<Customer> customers = new HashSet<>();
		
		try(Connection conn=DatabaseConnection.getConnection()) {
			PreparedStatement pst=conn.prepareStatement(mysql);
			ResultSet resultSet= pst.executeQuery();
			
			while(resultSet.next()) {
				Customer customer=new Customer();
				
				customer.setCustomerId(resultSet.getLong(1));
				customer.setCustomerName(resultSet.getString(2));
				customer.setEmail(resultSet.getString(3));
				customer.setMobileNo(resultSet.getString(4));
				customer.setAddress(resultSet.getString(5));
				customer.setPancard(resultSet.getString(6));
				
				customers.add(customer);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return customers;	
	}
	
	@Override
	public boolean changeCustomerMobileNo(Customer customer) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql="update customer set mobileNo=? where customerId=?;";
					
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, customer.getMobileNo());
			statement.setLong(2, customer.getCustomerId());
			
			int count = statement.executeUpdate();
			if(count>0) {
				return true;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return false;
	}



	@Override
	public boolean changeCustomerAddress(Customer customer) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql="update customer set address=? where customerId=?;";
					
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, customer.getAddress());
			statement.setLong(2, customer.getCustomerId());
			
			int count = statement.executeUpdate();
			if(count>0) {
				return true;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public long getLastAddedCustomerId() {
		String sql = "select max(customerId) from customer";
		try(Connection connection = DatabaseConnection.getConnection()) {
			PreparedStatement statementForId = connection.prepareStatement(sql);
			ResultSet resultSet = statementForId.executeQuery();
			if(resultSet.next()) {
				return resultSet.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
		return -1;
	}

}
