package com.thebank.view;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.FundTransfer;
import com.thebank.model.Payee;
import com.thebank.model.ServiceTracker;
import com.thebank.model.Transaction;
import com.thebank.model.User;
import com.thebank.service.AccountService;
import com.thebank.service.CustomerService;
import com.thebank.service.FundTransferService;
import com.thebank.service.IAccountService;
import com.thebank.service.ICustomerService;
import com.thebank.service.IFundTransferService;
import com.thebank.service.IPayeeService;
import com.thebank.service.IServiceTrackerService;
import com.thebank.service.ITransactionsService;
import com.thebank.service.IUserService;
import com.thebank.service.PayeeService;
import com.thebank.service.ServiceTrackerService;
import com.thebank.service.TransactionsService;
import com.thebank.service.UserService;

public class ServiceUI {

	static Scanner scanner = new Scanner(System.in);
	static IUserService userService = new UserService();
	static IAccountService accountService = new AccountService();
	static ITransactionsService transactionsService = new TransactionsService();
	static ICustomerService customerService = new CustomerService();
	static IServiceTrackerService serviceTrackerService = new ServiceTrackerService();
	static IPayeeService payeeService = new PayeeService();
	static IFundTransferService fundTransferService = new FundTransferService();
	
	public static void signUp() {
		Customer customer = PromptUI.promptCustomer();
		User user = PromptUI.promptUser(customer);
		
		
		boolean success = customerService.addCustomer(customer);		
		if(!success) {
			System.out.println("Error occured.");
		}else {
			long customerId = customerService.getLastAddedCustomerId();
			
			user.setCustomerId(customerId);
			boolean success2 = userService.addUser(user);
			if(!success2) {
				System.out.println("Error occured.");
			}else {
				System.out.println("Registration successful.");
			}
		}
	}
	
	public static void showMiniOrDetailedStatement(Customer customer) {
		int choice = MenuUI.getTypeOfStatement();
		switch (choice) {
			case 1:
				Set<Transaction> transactions1 = transactionsService.getLastNTransactionsForAccount(
						customer.getCustomerId(), 10);
				DisplayUI.printTransactions(transactions1);
				break;
			case 2:
				Set<Transaction> transactions2 = transactionsService.getTransactionsForCustomer(
						customer.getCustomerId());
				DisplayUI.printTransactions(transactions2);
				break;
			case 3:
				return;
		}
	}
	
	public static void changeAddressOrMobile(Customer customer) {
		int choice = MenuUI.getAddressOrMobileChangeType();
		switch (choice) {
			case 1:
				System.out.println("Current address is : "+customer.getAddress());
				System.out.println("Enter new address:");
		    	String newAddress = scanner.next();
		    	
		    	customer.setAddress(newAddress);
		    	customerService.changeCustomerAddress(customer);
				break;
			case 2:
				System.out.println("Current Mobile Number is : "+customer.getEmail());
				String newMobile = PromptUI.promptMobileNumber();
				
				customer.setMobileNo(newMobile);
		    	customerService.changeCustomerMobileNo(customer);
				break;
			case 3:
				return;
		}
	}
	
	public static void trackServiceRequest(Customer customer) {
		int choice = MenuUI.getTrackServiceType();
		switch (choice) {
			case 1:
				Set<ServiceTracker> serviceTrackers1 = serviceTrackerService.getAllServicesOfCustomer(customer.getCustomerId());
				DisplayUI.printServiceTrackers(serviceTrackers1);
				ServiceTracker serviceTracker = PromptUI.getServiceChoice(serviceTrackers1);
				if(serviceTracker!=null) {
					DisplayUI.printServiceTracker(serviceTracker);
				}
				break;
			case 2:
				Set<Account> accounts = accountService.getAllAccountsOfCustomer(customer.getCustomerId());
				Account account = PromptUI.getAccountChoice(accounts);
				Set<ServiceTracker> serviceTrackers2 = serviceTrackerService.getAllServicesOfAccount(account.getAccountId());
				DisplayUI.printServiceTrackers(serviceTrackers2);
				break;
			case 3:
				return;
		}
	}
	
	public static void doFundTransfer(Customer customer) {
		int choice = MenuUI.getTypeOfFundTransfer();
		
		if(choice==4) {
			return;
		}
		if(choice==3) {
			Payee payee = PromptUI.promptPayee(customer);
			if(payee!=null) {
				payeeService.addPayee(payee);
			}
			return;
		}

		Set<Account> accounts = accountService.getAllAccountsOfCustomer(customer.getCustomerId());
		Account account = PromptUI.getAccountChoice(accounts);
		
		long otherAccountId = 0;
		
		switch (choice) {
			case 1:
				Set<Account> otherAccounts = accountService.getAllAccountsExceptGivenAccountId(customer.getCustomerId(),account.getAccountId());
				Account other = PromptUI.getAccountChoice(otherAccounts);
				if(other==null) {
					return;
				}
				otherAccountId = other.getAccountId();
				break;
			case 2:
				Set<Payee> payees = payeeService.getAllPayeeOfAccountId(account.getAccountId());
				Payee payee = PromptUI.getPayeeChoice(payees);
				if(payee==null) {
					return;
				}
				otherAccountId = payee.getPayeeAccountId();
				break;
		}
		
		double amount = PromptUI.promptAmount("Enter Transaction Amount: ");
		
		FundTransfer fundTransfer = new FundTransfer();
		fundTransfer.setAccountId(account.getAccountId());
		fundTransfer.setPayeeAccountId(otherAccountId);
		fundTransfer.setDateOfTransfer(LocalDate.now());
		fundTransfer.setTransferAmount(amount);
		
		fundTransferService.addFundTransfer(fundTransfer);
	}
	

	public static void changePassword(User user) {
		boolean success = false;
    	do{
    		System.out.println("Enter new password");
			String pwd=scanner.next();
		   	System.out.println("Confirm password");
		   	String confirmPwd=scanner.next();
		   	if(pwd.equals(confirmPwd)) {
		   		user.setLoginPassword(pwd);
	    		success = userService.changeLoginPassword(user);
	    		if(success) {
		    		break;
	    		}
		   	}else {
			   	System.out.println("Password didn't match.");
		   	}
		   		
	    }while(!success);
	}
}
