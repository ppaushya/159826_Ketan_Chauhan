package com.thebank.service;

import java.util.Set;

import com.thebank.dao.CustomerDao;
import com.thebank.dao.ICustomerDao;
import com.thebank.model.Customer;

public class CustomerService implements ICustomerService{
	ICustomerDao customerDao = new CustomerDao();
	
	public boolean addCustomer(Customer customer) {
		
		if(customer==null)
		{
			throw new IllegalArgumentException();
		}
		
			return customerDao.addCustomer(customer);
	}

	@Override
	public Customer getCustomerFromCustomerId(long customerId) {
		return customerDao.getCustomerFromCustomerId(customerId);
	}

	@Override
	public Set<Customer> getAllCustomers() {
		return customerDao.getAllCustomers();
	}

	@Override
	public boolean changeCustomerAddress(Customer customer) {
		return customerDao.changeCustomerAddress(customer);
	}

	@Override
	public boolean changeCustomerMobileNo(Customer customer) {
		return customerDao.changeCustomerMobileNo(customer);
	}

	@Override
	public long getLastAddedCustomerId() {
		return customerDao.getLastAddedCustomerId();
	}

	@Override
	public boolean isEmailExists(String email) {
		return customerDao.isEmailExists(email);
	}

	@Override
	public boolean isPanCardExists(String panCard) {
		return customerDao.isPanCardExists(panCard);
	}
	
	

}
