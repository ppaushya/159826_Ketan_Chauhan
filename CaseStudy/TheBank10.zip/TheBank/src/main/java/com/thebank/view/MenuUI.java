package com.thebank.view;

import java.util.Scanner;

import com.thebank.service.AccountService;
import com.thebank.service.IAccountService;

public class MenuUI {

	static Scanner scanner = new Scanner(System.in); //Declare and initialize scanner
	static IAccountService accountService = new AccountService();

	//Prompt Login type from user
	public static int getTaskType() {
		
		System.out.println("\tWelcome to The Bank\nZindagi ke sath bhi, Zindagi ke baad bhi");
		System.out.println();
		System.out.println("Login as:");
		
		int choice=0;
		while(choice<1 || choice>4) {
			
			//Print login choices on console
			System.out.println("1.Account Holder");
			System.out.println("2.Bank Administrator");
			System.out.println("\nOR");
			System.out.println("\n3.New Customer? Sign Up");
			System.out.println("4.Exit");
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2,3,4]: ");
			
			choice = scanner.nextInt(); 
			//Prompt the user again incase invalid choice entered
			if(choice<1 || choice>4) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice; //Return Login choice
	}
	
	public static int getTaskChoiceOfCustomer(String customerName) {
		
		System.out.println();
		System.out.println("Hello! "+customerName);
		int choice=0;
		while(choice<1 || choice>7) {
			System.out.println("----------------------------------");
			System.out.println("1.View mini/Detailed Statement");
			System.out.println("2.Change in address/mobile Number");
			System.out.println("3.Request for Cheque Book");
			System.out.println("4.Track Service Request");
			System.out.println("5.Funds Transfer");
			System.out.println("6.Change Password");
			System.out.println("7.Exit");
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2,3,4,5,6,7]: ");
			
			choice = scanner.nextInt();
			if(choice<1 || choice>7) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getTaskChoiceOfAdmin() {
		
		int choice=0;
		while(choice<1 || choice>3) {
			System.out.println();
			System.out.println("----------------------------------");
			System.out.println("1.Create new account");
			System.out.println("2.View transactions of all accounts");
			System.out.println("3.Cancel");
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2,3]: ");
			
			choice = scanner.nextInt();
			if(choice<1 || choice>3) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getTypeOfStatement() {
		
		int choice=0;
		while(choice<1 || choice>3) {
			System.out.println();
			System.out.println("1.Mini statement");
			System.out.println("2.Detailed statement");
			System.out.println("3.Cancel");
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2,3]: ");
			
			choice = scanner.nextInt();
			if(choice<1 || choice>3) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getTypeOfFundTransfer() {
		
		int choice=0;
		while(choice<1 || choice>4) {
			System.out.println();
			System.out.println("1.In Own account");
			System.out.println("2.In Payee account");
			System.out.println("3.Add Payee");
			System.out.println("4.Cancel");
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2,3,4]: ");
			
			choice = scanner.nextInt();
			if(choice<1 || choice>4) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getAddressOrMobileChangeType() {
		
		int choice=0;
		while(choice<1 || choice>3) {
			System.out.println();
			System.out.println("1.Change Address");
			System.out.println("2.Change mobile number");
			System.out.println("3.Cancel");
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2]: ");
			
			choice = scanner.nextInt();
			if(choice<1 || choice>3) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getTrackServiceType() {
		int choice=0;
		while(choice<1 || choice>3) {
			System.out.println();
			System.out.println("View service by..");
			System.out.println("1.Service number");
			System.out.println("2.Account number");
			System.out.println("3.Cancel");
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2,3]: ");
			
			choice = scanner.nextInt();
			if(choice<1 || choice>3) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getTransactionSummaryType() {
		int choice=0;
		while(choice<1 || choice>5) {
			System.out.println();
			System.out.println("View Transaction for..");
			System.out.println("1.Yearly Transactions");
			System.out.println("2.Quaterly Transactions");
			System.out.println("3.Monthly Transactions");
			System.out.println("4.Daily Transactions");
			System.out.println("5.Cancel");
			
			
			System.out.println("Choose your Option:");
			System.out.println("Enter your choice[1,2,3,4,5]: ");
			
			choice = scanner.nextInt();
			if(choice<1 || choice>5) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	
	public static boolean getRepeatConfirmation() {
		boolean shouldRepeat = false;
		System.out.println("Do you wish to continue? [y/n]:");
		String choice = scanner.next();
		shouldRepeat = choice.charAt(0)=='y' || choice.charAt(0)=='Y';
		return shouldRepeat;
	}
	

}
