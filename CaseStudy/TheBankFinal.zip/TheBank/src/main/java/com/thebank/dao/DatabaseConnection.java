package com.thebank.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DatabaseConnection {
	final static Logger logger=Logger.getLogger(DatabaseConnection.class);
	public static Connection getConnection() {
		Connection connection = null;
		try {
			InputStream inputStream = DatabaseConnection.class.getClassLoader().getResourceAsStream("mysqldb.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			
			Class.forName(properties.getProperty("driverClass"));
			connection = DriverManager.getConnection(properties.getProperty("url")
					, properties.getProperty("user"), properties.getProperty("password"));
			return connection;
		} catch (ClassNotFoundException | SQLException | IOException e) {
			logger.error("Connection Error!");
			
			//e.printStackTrace();
		}
		return null;
	}
}
