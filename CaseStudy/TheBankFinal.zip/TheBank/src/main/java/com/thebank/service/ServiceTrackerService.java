package com.thebank.service;

import java.time.LocalDate;
import java.util.Set;

import com.thebank.dao.IServiceTrackerDao;
import com.thebank.dao.ServiceTrackerDao;
import com.thebank.model.Account;
import com.thebank.model.ServiceTracker;

public class ServiceTrackerService implements IServiceTrackerService{
	IServiceTrackerDao serviceTrackerDao = new ServiceTrackerDao();
	public ServiceTrackerService() {
		
	}
	
	public ServiceTrackerService(IServiceTrackerDao serviceTrackerDao) {
		this.serviceTrackerDao = serviceTrackerDao;
	}
	
	@Override
	public boolean addServiceTracker(ServiceTracker serviceTracker) {
		if(serviceTracker==null)
		{
			throw new IllegalArgumentException();
		}
		return serviceTrackerDao.addServiceTracker(serviceTracker);
	}
    
	//adding the cheque book request of the customer
	@Override
	public boolean addChequebookRequest(Account account) {
		ServiceTracker serviceTracker = new ServiceTracker();
		serviceTracker.setAccountId(account.getAccountId());
		serviceTracker.setServiceDescription("New Cheque Book request");
		serviceTracker.setServiceRaisedDate(LocalDate.now());
		serviceTracker.setServiceStatus("Open");
		
		return serviceTrackerDao.addServiceTracker(serviceTracker);
	}

	@Override
	public ServiceTracker getServiceFromServiceId(long serviceId) {
		return serviceTrackerDao.getServiceFromServiceId(serviceId);
	}

	@Override
	public Set<ServiceTracker> getAllServicesOfCustomer(long customerId) {
		return serviceTrackerDao.getAllServicesOfCustomer(customerId);
	}

	@Override
	public Set<ServiceTracker> getAllServicesOfAccount(long accountId) {
		return serviceTrackerDao.getAllServicesOfAccount(accountId);
	}

}
