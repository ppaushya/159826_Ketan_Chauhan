package com.thebank.service;

import java.util.Set;

import com.thebank.dao.AccountDao;
import com.thebank.dao.IAccountDao;
import com.thebank.dao.ITransactionsDao;
import com.thebank.dao.TransactionsDao;
import com.thebank.exception.InvalidAmountException;
import com.thebank.model.Account;
import com.thebank.model.Transaction;

public class AccountService implements IAccountService{
	IAccountDao accountDao = new AccountDao();
	ITransactionsDao transactionsDao = new TransactionsDao();
	
	public AccountService() {

	}
	
	public AccountService(IAccountDao accountDao,ITransactionsDao transactionsDao) {
		this.accountDao = accountDao;
		this.transactionsDao = transactionsDao;
	}
	
	//create account service method
	public boolean addAccount(Account account) throws InvalidAmountException {
		if(account==null)
		{
			throw new IllegalArgumentException();
		}
		else if(account.getAccountBalance()<5000)
		{
			throw new InvalidAmountException("Minimum account balance must be Rs. 5000. Try Again!");
		}
		return accountDao.addAccount(account);
	}

	
	//retrieve account details using account ID
	@Override
	public Account getAccountFromAccountId(long accountId) {
		return accountDao.getAccountFromAccountId(accountId);
	}
	
	//retrieve accounts of customer
	@Override
	public Set<Account> getAllAccountsOfCustomer(long customerId) {
		return accountDao.getAllAccountsOfCustomer(customerId);
	}


	//retireve accounts except those of given customer
	@Override
	public Set<Account> getAllAccountsExceptGivenCustomer(long customerId) {
		return accountDao.getAllAccountsExceptGivenCustomer(customerId);
	}

	//retireve accounts except given account
	@Override
	public Set<Account> getAllAccountsExceptGivenAccountId(long customerId,long accountId) {
		return accountDao.getAllAccountsExceptGivenAccountId(customerId,accountId);
	}

	//get opening balance of an account
	@Override
	public double getOpeningBalance(long accountNo) {
		// TODO Auto-generated method stub
		return accountDao.getOpeningBalance(accountNo);
	}

	//calculating the current balance 
	@Override
	public double getCurrentBalanceForAccount(Account account) {
		// TODO Auto-generated method stub
		double currentBalance=account.getAccountBalance();
		Set<Transaction> transactions=transactionsDao.getTransactionsForAccount(account.getAccountId());
		
		for(Transaction transaction:transactions)
		{
			if(transaction.getTransactionType()=='D')
			{
				currentBalance-=transaction.getAmount();
			}
			else if(transaction.getTransactionType()=='C')
			{
				currentBalance+=transaction.getAmount();
			}
		}
		return currentBalance;
	}
	

}
