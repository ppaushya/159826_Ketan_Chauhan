package com.thebank.view;

import java.util.Scanner;

import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.User;
import com.thebank.service.AccountService;
import com.thebank.service.CustomerService;
import com.thebank.service.IAccountService;
import com.thebank.service.ICustomerService;
import com.thebank.service.IServiceTrackerService;
import com.thebank.service.IUserService;
import com.thebank.service.ServiceTrackerService;
import com.thebank.service.UserService;

public class UserInteraction {

	static Scanner scanner = new Scanner(System.in);
	static IUserService userService = new UserService();
	static ICustomerService customerService = new CustomerService();
	static IAccountService accountService = new AccountService();
	static IServiceTrackerService serviceTrackerService = new ServiceTrackerService();

	//prompt the account holder login credentials
	public static void doCustomerTasks() {
		
		User user = PromptUI.promptLoginCredentialAndGetUser();
		if(user==null) {
			return;
		}
		Customer customer = customerService.getCustomerFromCustomerId(user.getCustomerId());
		if(customer==null) {
			return;
		}
		
		do {
			int choice = MenuUI.getTaskChoiceOfCustomer(customer.getCustomerName());
			
			switch(choice)
		    {
			    case 1: //show the mini/detailed statement
			    	ServiceUI.showMiniOrDetailedStatement(customer);
			    	break;
			    	
			    case 2:   //change address and mobile number
			    	ServiceUI.changeAddressOrMobile(customer);
			    	break;
			    	
			    case 3: //adding the cheque book request of customer
			    	Account account = PromptUI.getAccountChoice(
			    	accountService.getAllAccountsOfCustomer(customer.getCustomerId()));
			    	if(account!=null) {
				    	serviceTrackerService.addChequebookRequest(account);
			    	}
			    	break;
			    	
			    case 4: //track the service request
			    	ServiceUI.trackServiceRequest(customer);
			    	break;
			    	
			    case 5: //funds transfer 
			    	ServiceUI.doFundTransfer(customer,user);
			    	break;
			    	
			    case 6://changing the password 
			    	ServiceUI.changePassword(user);
			    	break;
			    	
			    case 7://calculating the current balance 
			    	ServiceUI.printCurrentBalance(customer);
			    	break;
					    	
			    case 8://exit 
			    	return;
		    }
		}while(MenuUI.getRepeatConfirmation());
		
	}
	
	//doing the admin tasks 
	public static void doAdminTasks() {
		do {
			int choice = MenuUI.getTaskChoiceOfAdmin();
			
			switch(choice)
		    {
			    case 1:
			    	AdminServiceUI.createNewAccount();
			    	break;
			    	
			    case 2:
			    	AdminServiceUI.viewTransaction();
			    	break;
			    	
		    	case 3:
		    		return;
		    }
		}while(MenuUI.getRepeatConfirmation());
	}	
}