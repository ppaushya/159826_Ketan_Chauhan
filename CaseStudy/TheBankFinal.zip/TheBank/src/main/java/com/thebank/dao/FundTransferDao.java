package com.thebank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.thebank.model.FundTransfer;

public class FundTransferDao implements IFundTransferDao{
	
	final static Logger logger=Logger.getLogger(FundTransferDao.class);

	private static final String FUND_TRANSFER_TABLE = "fundTransfer";
	private static final String COLUMN_FUND_TRANSFER_ID = "fundTransferId";
	private static final String COLUMN_ACCOUNT_ID = "accountId";
	private static final String COLUMN_PAYEE_ACCOUNT_ID = "payeeAccountId";
	private static final String COLUMN_DATE_OF_TRANSFER = "dateOfTransfer";
	private static final String COLUMN_TRANSFER_AMOUNT = "transferAmount";
	
	//adding the funds transfer in DB
	@Override
	public boolean addFundTransfer(FundTransfer fundTransfer) {
		try(Connection connection = DatabaseConnection.getConnection()) {

			String sql="insert into "+FUND_TRANSFER_TABLE+"("
					+COLUMN_FUND_TRANSFER_ID+","
					+COLUMN_ACCOUNT_ID+","
					+COLUMN_PAYEE_ACCOUNT_ID+","
					+COLUMN_DATE_OF_TRANSFER+","
					+COLUMN_TRANSFER_AMOUNT+")"
					+" values(?,?,?,?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setLong(1, fundTransfer.getFundTranferId());
			preparedStatement.setLong(2, fundTransfer.getAccountId());
			preparedStatement.setLong(3, fundTransfer.getPayeeAccountId());
			preparedStatement.setDate(4, Date.valueOf(fundTransfer.getDateOfTransfer()));
			preparedStatement.setDouble(5, fundTransfer.getTransferAmount());
			
			int count = preparedStatement.executeUpdate();
			
			if(count>0) {
				logger.info("Fund Transfer done successfully");
				return true;
			}
		} catch (SQLException e) {
			logger.error("Fund Transfer failed");
			//e.printStackTrace();
		}
		return false;
	}

	@Override
	public FundTransfer getFundTransferFromFundTranferId(long fundTranferId) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+FUND_TRANSFER_TABLE;
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				FundTransfer fundTransfer = new FundTransfer();
				fundTransfer.setFundTranferId(resultSet.getLong(COLUMN_FUND_TRANSFER_ID));
				fundTransfer.setAccountId(resultSet.getLong(COLUMN_ACCOUNT_ID));
				fundTransfer.setPayeeAccountId(resultSet.getLong(COLUMN_PAYEE_ACCOUNT_ID));
				fundTransfer.setDateOfTransfer(resultSet.getDate(COLUMN_DATE_OF_TRANSFER).toLocalDate());
				fundTransfer.setTransferAmount(resultSet.getDouble(COLUMN_TRANSFER_AMOUNT));
				logger.info("Fund Transfer exists");
				return fundTransfer;
			}
			else {
				logger.info("Fund Transfer does not exist");
			}
			
		} catch (SQLException e) {
			logger.error("Fund transfer retrieval failed");
			//e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<FundTransfer> getAllFundTransfers() {
		Set<FundTransfer> fundTransfers = new HashSet<>();
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+FUND_TRANSFER_TABLE;
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				FundTransfer fundTransfer = new FundTransfer();
				fundTransfer.setFundTranferId(resultSet.getLong(COLUMN_FUND_TRANSFER_ID));
				fundTransfer.setAccountId(resultSet.getLong(COLUMN_ACCOUNT_ID));
				fundTransfer.setPayeeAccountId(resultSet.getLong(COLUMN_PAYEE_ACCOUNT_ID));
				fundTransfer.setDateOfTransfer(resultSet.getDate(COLUMN_DATE_OF_TRANSFER).toLocalDate());
				fundTransfer.setTransferAmount(resultSet.getDouble(COLUMN_TRANSFER_AMOUNT));
				
				fundTransfers.add(fundTransfer);
			}
			if(fundTransfers.size()==0) {
				logger.info("No Fund Transfer Transactions exist");
			}
			else {
				logger.info("Fund Transfer transactions exist");
			}
			return fundTransfers;
			
		} catch (SQLException e) {
			logger.error("Fund Transfer Retrieval failed");
			//e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Set<FundTransfer> getAllFundTransfersFromAccountId(long accountId) {
		Set<FundTransfer> fundTransfers = new HashSet<>();
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+FUND_TRANSFER_TABLE+" where "
					+ COLUMN_ACCOUNT_ID +"=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, accountId);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				FundTransfer fundTransfer = new FundTransfer();
				fundTransfer.setFundTranferId(resultSet.getLong(COLUMN_FUND_TRANSFER_ID));
				fundTransfer.setAccountId(resultSet.getLong(COLUMN_ACCOUNT_ID));
				fundTransfer.setPayeeAccountId(resultSet.getLong(COLUMN_PAYEE_ACCOUNT_ID));
				fundTransfer.setDateOfTransfer(resultSet.getDate(COLUMN_DATE_OF_TRANSFER).toLocalDate());
				fundTransfer.setTransferAmount(resultSet.getDouble(COLUMN_TRANSFER_AMOUNT));

				fundTransfers.add(fundTransfer);
			}
			if(fundTransfers.size()==0) {
				logger.info("No Fund Transfer Transactions exist");
			}
			else {
				logger.info("Fund Transfer transactions exist");
			}
			return fundTransfers;
			
		} catch (SQLException e) {
			logger.error("Fund Transfer Retrieval failed");
			//e.printStackTrace();
		}
		return null;
	}

}
