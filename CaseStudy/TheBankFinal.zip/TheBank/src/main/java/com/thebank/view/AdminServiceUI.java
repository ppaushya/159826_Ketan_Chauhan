package com.thebank.view;

import java.util.Set;

import org.apache.log4j.Logger;

import com.thebank.exception.InvalidAmountException;
import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.Transaction;
import com.thebank.service.AccountService;
import com.thebank.service.CustomerService;
import com.thebank.service.IAccountService;
import com.thebank.service.ICustomerService;
import com.thebank.service.ITransactionsService;
import com.thebank.service.TransactionsService;

public class AdminServiceUI {
static ICustomerService customerService=new CustomerService();
static IAccountService accountService = new AccountService();
static ITransactionsService transactionsService=new TransactionsService();
final static Logger logger=Logger.getLogger(AdminServiceUI.class);

    //creation of new account by admin 
	public static void createNewAccount() {
		Customer customer = PromptUI.getCustomerChoice(customerService.getAllCustomers());
		if(customer==null) {
			return;
		}
		Account account = PromptUI.promptAccount(customer);
		try {
			boolean success = accountService.addAccount(account);
			if(success) {
				System.out.println("Account Created!");
			}
		} catch (InvalidAmountException e) {
			System.out.println("Minimum account balance should be 5000.");
			logger.error("Minimum account balance should be 5000.");
			//e.printStackTrace();
		}
	}
	
	//view different transaction in particular duration 
	public static void viewTransaction() {
		do {
			int choice=MenuUI.getTransactionSummaryType();
			switch(choice)
			{
				case 1:
					 Set<Transaction> transactions=transactionsService.getYearlyTransactions();
				     DisplayUI.printTransactions(transactions); 
					  break;	
				      
				case 2:   
					 Set<Transaction> transactions1=transactionsService.getQuarterlyTransactions();
				     DisplayUI.printTransactions(transactions1); 
					  break;	
					  
				case 3:   
					 Set<Transaction> transactions2=transactionsService.getMonthlyTransactions();
				     DisplayUI.printTransactions(transactions2); 
					 break;	
						      
				case 4:   
					 Set<Transaction> transactions3=transactionsService.getDailyTransactions();
				     DisplayUI.printTransactions(transactions3); 
					 break;	
					 
				case 5:
					 return;
			 }
		}while(MenuUI.getRepeatConfirmation());
	}
}
