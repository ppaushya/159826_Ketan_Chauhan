package com.thebank.service;

import java.time.LocalDate;
import java.util.HashSet;

import org.junit.Before;

import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.thebank.dao.IAccountDao;
import com.thebank.dao.IFundTransferDao;
import com.thebank.dao.ITransactionsDao;
import com.thebank.exception.InsufficientAccountBalanceException;
import com.thebank.model.Account;
import com.thebank.model.AccountType;
import com.thebank.model.FundTransfer;
import com.thebank.model.Transaction;

public class FundTransferServiceTest {

	@Mock
	IFundTransferDao fundTransferDao;
	static IFundTransferService fundTransferServices;
	
	@Mock
	IAccountDao accountDao;
	static IAccountService accountService;
	
	@Mock
	ITransactionsDao transactionsDao;
	static ITransactionsService transactionsService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		accountService = new AccountService(accountDao,transactionsDao);
		transactionsService = new TransactionsService(transactionsDao);
		fundTransferServices = new FundTransferService(fundTransferDao,accountService,transactionsService);
	}


	@Test(expected = IllegalArgumentException.class)
	public void test_fundTransfer__creation() throws InsufficientAccountBalanceException {
		FundTransfer fundTransfer = null;

		fundTransferServices.addFundTransfer(fundTransfer);

	}

	@Test(expected = InsufficientAccountBalanceException.class)
	public void test_invalid_fundTransfer_account() throws InsufficientAccountBalanceException {
		Account account=new Account(101, AccountType.SAVINGS, LocalDate.now(),1000);
		FundTransfer fundTransfer = new FundTransfer(1,101,102,LocalDate.now(),1000000);
		
		Mockito.when(accountService.getAccountFromAccountId(101)).thenReturn(account);

		Mockito.when(fundTransferServices.addFundTransfer(fundTransfer)).thenReturn(true);
		fundTransferServices.addFundTransfer(fundTransfer);

	}

	@Test
	public void test_fundTransfer_successful() throws InsufficientAccountBalanceException {
		FundTransfer fundTransfer = new FundTransfer(101,102,LocalDate.now(),100);
		Account account=new Account(101, AccountType.SAVINGS, LocalDate.now(),1000);

		Mockito.when(accountService.getAccountFromAccountId(101)).thenReturn(account);
		Mockito.when(transactionsDao.getTransactionsForAccount(101)).thenReturn(new HashSet<Transaction>());
		
		Mockito.when(fundTransferDao.addFundTransfer(fundTransfer)).thenReturn(true);
		fundTransferServices.addFundTransfer(fundTransfer);
		Mockito.verify(fundTransferDao).addFundTransfer(fundTransfer);

	}

}
