package com.thebank.service;

import com.thebank.dao.CustomerDao;
import com.thebank.dao.ICustomerDao;
import com.thebank.model.Customer;

public class CustomerService implements ICustomerService{

	ICustomerDao customerDao=new CustomerDao();
	
	public boolean addCustomer(Customer customer) {
		
		return customerDao.addCustomer(customer);
	}

	public Customer getCustomer(long customerId) {
		
		return customerDao.getCustomer(customerId);
	}

	
	@Override
	public boolean changeCustomerAddress(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean changeCustomerMobileNo(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

}
