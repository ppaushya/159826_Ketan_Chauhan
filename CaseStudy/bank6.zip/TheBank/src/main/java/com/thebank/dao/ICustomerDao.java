package com.thebank.dao;

import com.thebank.model.Customer;

public interface ICustomerDao {

	public boolean addCustomer(Customer customer);
	public Customer getCustomer(long customerId);
	
}
