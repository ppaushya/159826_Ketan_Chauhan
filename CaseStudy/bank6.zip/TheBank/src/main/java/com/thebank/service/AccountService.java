package com.thebank.service;

import java.util.Set;

import com.thebank.model.Account;

public class AccountService implements IAccountService{

	public boolean addAccount() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Account getAccountFromAccountId(long accountId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Set<Account> getAllAccountsOfCustomer(long customerId) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Set<Account> getAllAccountsExceptGivenCustomer(long customerId) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Set<Account> getAllAccountsExceptGivenAccountId(long accountId) {
		// TODO Auto-generated method stub
		return null;
	}


}
