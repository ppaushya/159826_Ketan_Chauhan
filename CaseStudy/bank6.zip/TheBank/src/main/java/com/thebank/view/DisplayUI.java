package com.thebank.view;

import java.util.List;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.AccountType;
import com.thebank.model.ServiceTracker;
import com.thebank.model.Transaction;

public class DisplayUI {

	public static void printAccounts(List<Account> accounts) {
		System.out.println("AccountId\tAccount Type\t Account_balance\t Account OpeningDate");
		System.out.println("------------------------------------------------------------------------------------------------------");
		for(Account account:accounts)
		{
			System.out.println(account.getAccountId()+"\t\t"+account.getAccountType()+"\t\t"+account.getAccountBalance()+"\t\t"+account.getOpenDate()); 
		}
		
	}
	
	
	
	public static void printTransactions(Set<Transaction> transactions) {
		System.out.println("TransactionId\t Transaction Type\t Transaction Amount\t TransactionDate");
		System.out.println("------------------------------------------------------------------------------------------------------");
		for(Transaction transaction:transactions)
		{
			System.out.println(transaction.getTransactionId()+"\t\t"+transaction.getTransactionType()+"\t\t"+transaction.getAmount()+"\t\t"+transaction.getTransactionDate()); 
		}
	}
	
	public static void printServiceTrackers(Set<ServiceTracker> serviceTrackers) {
		
		//System.out.println("AccountId\tAccount Type\t Account_balance\t Account OpeningDate");
		System.out.println("------------------------------------------------------------------------------------------------------");
		for(ServiceTracker serviceTracker:serviceTrackers)
		{
			//System.out.println(account.getAccountId()+"\t\t"+account.getAccountType()+"\t\t"+account.getAccountBalance()+"\t\t"+account.getOpenDate()); 
		}
		
	}
	
	public static void printServiceTracker(ServiceTracker serviceTracker) {
		//TODO mkae
		//System.out.println("AccountId\tAccount Type\t Account_balance\t Account OpeningDate");
		System.out.println("------------------------------------------------------------------------------------------------------");
		 //System.out.println(account.getAccountId()+"\t\t"+account.getAccountType()+"\t\t"+account.getAccountBalance()+"\t\t"+account.getOpenDate()); 
	}
	
}
