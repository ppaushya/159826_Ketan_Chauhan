package com.thebank.dao;

import java.util.Set;

import com.thebank.model.User;

public interface IUserDao {
	
	public boolean addUser(User user);
	public User getUserFromUserId(long userId);
	public Set<User> getAllUsers();
	
	public boolean changeLoginPassword(User user);
	public boolean changeTransactionPassword(User user);
	public boolean changeLockStatus(User user);
}
