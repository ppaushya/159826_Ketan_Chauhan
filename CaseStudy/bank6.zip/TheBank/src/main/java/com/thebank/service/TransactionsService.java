package com.thebank.service;

import java.util.Set;

import com.thebank.model.Transaction;

public class TransactionsService implements ITransactionsService{

	public boolean addTransaction() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean getTransaction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Set<Transaction> getTransactionsForAccount(long accountId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Transaction> getTransactionsForCustomer(long customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Transaction> getLastNTransactionsForAccount(long customerId, int count) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Transaction> getDailyTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Transaction> getMonthlyTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Transaction> getQuarterlyTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Transaction> getYearlyTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

}
