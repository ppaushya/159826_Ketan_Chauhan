package com.thebank.view;

import java.util.Scanner;

import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.User;
import com.thebank.service.AccountService;
import com.thebank.service.CustomerService;
import com.thebank.service.IAccountService;
import com.thebank.service.ICustomerService;
import com.thebank.service.IServiceTrackerService;
import com.thebank.service.IUserService;
import com.thebank.service.ServiceTrackerService;
import com.thebank.service.UserService;

public class UserInteraction {

	static Scanner scanner = new Scanner(System.in); //declare and initialize scanner object
	static IUserService userService = new UserService();
	static ICustomerService customerService = new CustomerService();
	static IAccountService accountService = new AccountService();
	static IServiceTrackerService serviceTrackerService = new ServiceTrackerService();

	//Display and return the Task chosen for customer login
	public static void doCustomerTasks() {
		
		
		User user = PromptUI.promptLoginCredentialAndGetUser(); //Prompt user for login credentials and return user identified by customerId
		Customer customer = customerService.getCustomerFromCustomerId(user.getCustomerId()); //Fetch the complete customer object/details through customerId
		
		do {
			int choice = MenuUI.getTaskChoiceOfCustomer(customer.getCustomerName()); //Return Task choice no. from user
			
			switch(choice)
		    {
			    case 1:
			    	ServiceUI.showMiniOrDetailedStatement(customer); //Invoke Mini/detailed transaction retrieval method
			    	break;
			    	
			    case 2:
			    	ServiceUI.changeAddressOrMobile(customer);//Invoke Change address Method
			    	break;
			    	
			    case 3:
			    	//Display all accounts from user
			    	//Allow User to choose the account for which cheque book is desired
			    	Account account = PromptUI.getAccountChoice(
			    			accountService.getAllAccountsOfCustomer(customer.getCustomerId()));
			    	if(account!=null) {
				    	serviceTrackerService.addChequebookRequest(account);
			    	}
			    	break;
			    	
			    case 4:
			    	ServiceUI.trackServiceRequest(customer);//Return the Status of the Service request
			    	break;
			    	
			    case 5:
			    	ServiceUI.doFundTransfer(customer);
			    	break;
			    	
			    case 6:
			    	ServiceUI.changePassword(user);
			    	break;
					    	
			    case 7:
			    	return;
		    }
		}while(MenuUI.getRepeatConfirmation());
		
	}
	
	public static void doAdminTasks() {
		do {
			int choice = MenuUI.getTaskChoiceOfAdmin();
			
			switch(choice)
		    {
			    case 1:
			    	AdminServiceUI.createNewAccount();
			    	break;
			    	
			    case 2:
			    	AdminServiceUI.viewTransaction();
			    	break;
			    	
		    	case 3:
		    		return;
		    }
		}while(MenuUI.getRepeatConfirmation());
	}
	
}
