package org.xyz.service;

import java.util.Set;

import org.xyz.model.Account;

public interface IAccountService {

	public boolean addAccount(Account account);
	public Set<Account> getAccountsOfCustomer(long customerId);

	public Account getAccountFromAccountNumber(long accountNumber);
	public double getCurrentBalanceOfAccount(Account account);
}
