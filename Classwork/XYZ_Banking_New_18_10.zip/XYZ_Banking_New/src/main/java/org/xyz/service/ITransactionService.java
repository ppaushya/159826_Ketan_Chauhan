package org.xyz.service;

import java.util.Set;

import org.xyz.model.Transaction;

public interface ITransactionService {

	public Set<Transaction> getAllTransactionsOfCustomer(long customerId);
	public Set<Transaction> getAllTransactionsOfAccount(long accountNumber);
	public boolean createTransaction(Transaction transaction);
}
