package org.cap.service;

import org.cap.model.CustomerBean;

public interface IRegisterService {

	public boolean registerCustomer(CustomerBean customerBean);
}
