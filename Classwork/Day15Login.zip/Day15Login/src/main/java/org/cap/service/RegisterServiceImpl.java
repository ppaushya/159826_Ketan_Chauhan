package org.cap.service;

import org.cap.dao.IRegisterDao;
import org.cap.dao.RegisterDaoImpl;
import org.cap.model.CustomerBean;

public class RegisterServiceImpl implements IRegisterService{
	IRegisterDao registerDao = new RegisterDaoImpl();
	
	@Override
	public boolean registerCustomer(CustomerBean customerBean) {
		return registerDao.registerCustomer(customerBean);
	}
}
