package org.cap.dao;

import org.cap.model.CustomerBean;

public interface IRegisterDao {

	public boolean registerCustomer(CustomerBean customerBean);
}
