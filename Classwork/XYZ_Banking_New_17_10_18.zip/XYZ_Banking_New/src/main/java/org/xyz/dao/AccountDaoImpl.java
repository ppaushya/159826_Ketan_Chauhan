package org.xyz.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.xyz.model.Account;

public class AccountDaoImpl implements IAccountDao{

	private Connection getConnection() {
		Connection connection = null;
		try {
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream("mysqldb.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			
			Class.forName(properties.getProperty("driverClass"));
			connection = DriverManager.getConnection(properties.getProperty("url")
					, properties.getProperty("user"), properties.getProperty("password"));
			return connection;
		} catch (ClassNotFoundException | SQLException | IOException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean addAccount(Account account) {
		try(Connection connection = getConnection()) {

			String sql="insert into account values(null,?,?,?,?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setDouble(1, account.getCustomer().getCustomerId());
			preparedStatement.setString(2, account.getAccountType().toString());
			preparedStatement.setDate(3,Date.valueOf(account.getOpeningDate()));
			preparedStatement.setDouble(4, account.getOpeningBalance());
			preparedStatement.setString(5, account.getDescription());
			
			int c =preparedStatement.executeUpdate();
			
			if(c>0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
	}
}
