package org.xyz.dao;

import org.xyz.model.Account;

public interface IAccountDao {

	public boolean addAccount(Account account);
}
