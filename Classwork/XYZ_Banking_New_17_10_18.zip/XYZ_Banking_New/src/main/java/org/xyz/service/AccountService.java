package org.xyz.service;

import org.xyz.dao.AccountDaoImpl;
import org.xyz.dao.IAccountDao;
import org.xyz.model.Account;

public class AccountService implements IAccountService{

	IAccountDao accountDao = new AccountDaoImpl();
	
	@Override
	public boolean addAccount(Account account) {
		return accountDao.addAccount(account);
	}

}
