package org.xyz.service;

import org.xyz.model.Account;

public interface IAccountService {

	public boolean addAccount(Account account);
}
