function validateAccount(){
	console.log("validateAccount");
	
	var balErrMsg = document.getElementById("balErrMsg");
	
	var balance = accountform.balance.value;
	
	var success = false;
	
	if(balance==null || balance<=0){
		balErrMsg.innerHTML = "Please enter valid balance";
		success = false;
	}else {
		success = true;
	}
	
	return success;
}