package org.xyz.dao;

import org.xyz.model.LoginBean;

public interface ILoginDao {

	public boolean isValidLogin(LoginBean loginBean);
}
