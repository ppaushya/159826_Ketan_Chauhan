package org.capg.model;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	
	@Id
	private int customerId;
	private String firstName;
	private String lastName;
	private LocalDate dateOfBirth;
	private String emailId;
	private String mobile;
	private String customerPwd;
	@OneToOne
	@JoinColumn(name="address_fk")
	private Address address;
	
	@OneToMany(mappedBy="customer", targetEntity=Account.class,cascade=CascadeType.ALL)
	private Set<Account> accounts;
	
	@ManyToMany
	@JoinTable(name="customer_transaction",joinColumns= {@JoinColumn(name="transactions")},
	inverseJoinColumns= {@JoinColumn(name="customers")} )
	private List<Transaction> transactions=new ArrayList<>();
	
	public Customer() {
		
	}
	
	
	
	
	public List<Transaction> getTransactions() {
		return transactions;
	}




	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}




	public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String emailId,
			String mobile, Address address) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.mobile = mobile;
		this.address = address;
	}




	public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String emailId,
			String mobile, Address address, Set<Account> accounts) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.mobile = mobile;
		this.address = address;
		this.accounts = accounts;
	}
	
	
	public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String emailId,
			String mobile, String customerPwd, Address address, Set<Account> accounts) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.mobile = mobile;
		this.customerPwd = customerPwd;
		this.address = address;
		this.accounts = accounts;
	}




	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Set<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(Set<Account> accounts) {
		this.accounts = accounts;
	}
	
	
	
	public String getCustomerPwd() {
		return customerPwd;
	}




	public void setCustomerPwd(String customerPwd) {
		this.customerPwd = customerPwd;
	}




	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", dateOfBirth=" + dateOfBirth + ", emailId=" + emailId + ", mobile=" + mobile + ", customerPwd="
				+ customerPwd + ", address=" + address + ", accounts=" + accounts + "]";
	}




	
	
	
}
