export interface IAccount{
    accountNumber:number;
    accountType:string;
    openingDate:string;
    openingBalance:number;
    description:string;
    customer:string;
}