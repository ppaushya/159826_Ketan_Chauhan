import {Component, OnInit} from '@angular/core';
import { IAccount } from '../account/account';
import { AccountService } from '../../api/account/account.service';

@Component({
    selector:'pm-fund-transfer',
    templateUrl: './fund-transfer.component.html',
    providers: [AccountService],
    styleUrls: ['./fund-transfer.component.css']
})

export class FundTransferComponent implements OnInit{
    pageTitle: string='Fund Transfer';
    errorMessage: string;

    accounts:IAccount[] = [];

    constructor(private _accountService: AccountService){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        this._accountService.getAccounts()
            .subscribe(
                accounts => {
                    this.accounts = accounts;
                },
                error => this.errorMessage = <any>error
            );
    }
}