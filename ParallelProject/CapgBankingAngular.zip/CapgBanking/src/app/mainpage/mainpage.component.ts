import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector:'pm-mainpage',
    templateUrl: './mainpage.component.html',
    styleUrls: ['./mainpage.component.css']
})

export class MainPageComponent implements OnInit{
    pageTitle: string='Mainpage';
    

    constructor(private router: Router){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        
        this.router.navigate(['/mainpage/createaccount']);
    }
}