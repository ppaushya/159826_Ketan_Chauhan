import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector:'pm-dv',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit{
    pageTitle: string='Register';
    

    constructor(private router: Router){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        
    }

    register(){
        this.router.navigate(['/login']);
    }

    goToLogin(){
        this.router.navigate(['/login']);
    }
}