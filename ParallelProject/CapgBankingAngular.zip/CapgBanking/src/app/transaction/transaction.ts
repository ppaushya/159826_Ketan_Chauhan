export interface ITransaction{
    transactionId:number;
    transactionDate:string;
    fromAccount:number;
    toAccount:number;
    amount:number;
    transactionType:string;
    description:string;
}