import {Component, OnInit} from '@angular/core';
import { IAccount } from '../account/account';
import { AccountService } from '../../api/account/account.service';

@Component({
    selector:'pm-depositwithdrawal',
    templateUrl: './depositwithdrawal.component.html',
    providers: [AccountService],
    styleUrls: ['./depositwithdrawal.component.css']
})

export class DepositeWithdrawalComponent implements OnInit{
    pageTitle: string='Deposite/Withdrawal';
    errorMessage: string;

    accounts:IAccount[] = [];

    constructor(private _accountService: AccountService){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        this._accountService.getAccounts()
            .subscribe(
                accounts => {
                    this.accounts = accounts;
                },
                error => this.errorMessage = <any>error
            );
    }
}