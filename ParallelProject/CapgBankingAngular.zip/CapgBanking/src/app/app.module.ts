import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { WelcomeComponent } from './home/welcome.component';
import { MainPageComponent } from './mainpage/mainpage.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { TransactionSummaryComponent } from './transaction-summary/transaction-summary.component';
import { DepositeWithdrawalComponent } from './depositwithdrawal/depositwithdrawal.component';

@NgModule({
  declarations: [
    WelcomeComponent,
    AppComponent,
    MainPageComponent,
    LoginComponent,
    RegisterComponent,
    CreateAccountComponent,
    DepositeWithdrawalComponent,
    FundTransferComponent,
    TransactionSummaryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'welcome', component: WelcomeComponent },

      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterComponent },

      {
        path: 'mainpage', component: MainPageComponent, children: [
          { path: 'createaccount', component: CreateAccountComponent },
          { path: 'depositewithdrawal', component: DepositeWithdrawalComponent },
          { path: 'fundtransfer', component: FundTransferComponent },
          { path: 'transactionsummary', component: TransactionSummaryComponent }
        ]
      },
      { path: '', redirectTo: 'welcome', pathMatch: 'full' },
      { path: '**', redirectTo: 'welcome', pathMatch: 'full' }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
