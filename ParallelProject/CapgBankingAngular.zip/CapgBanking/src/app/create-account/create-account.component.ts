import {Component, OnInit} from '@angular/core';
import { IAccount } from '../account/account';
import { AccountService } from '../../api/account/account.service';

@Component({
    selector:'pm-create-account',
    templateUrl: './create-account.component.html',
    styleUrls: ['./create-account.component.css']
})

export class CreateAccountComponent implements OnInit{
    pageTitle: string='Create Account';
    errorMessage: string;

    accounts:IAccount[] = [];

    constructor(){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        
    }
}