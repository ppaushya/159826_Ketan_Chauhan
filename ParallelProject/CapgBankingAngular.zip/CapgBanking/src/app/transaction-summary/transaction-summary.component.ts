import {Component, OnInit} from '@angular/core';
import { IAccount } from '../account/account';
import { AccountService } from '../../api/account/account.service';
import { TransactionService } from '../../api/transaction/transaction.service';
import { ITransaction } from '../transaction/transaction';

@Component({
    selector:'pm-transaction-summary',
    templateUrl: './transaction-summary.component.html',
    providers: [TransactionService],
    styleUrls: ['./transaction-summary.component.css']
})

export class TransactionSummaryComponent implements OnInit{
    pageTitle: string='Transaction Summary';
    errorMessage: string;

    transactions:ITransaction[] = [];

    constructor(private _transactionService: TransactionService){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        this.refreshTransactions();
    }

    refreshTransactions():void{
        this._transactionService.getTransactions()
        .subscribe(
            transactions => {
                this.transactions = transactions;
            },
            error => this.errorMessage = <any>error
        );
    }
}