import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector:'pm-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit{
    pageTitle: string='Login';
    

    constructor(private router: Router){
        
    }

    ngOnInit(): void {
        console.log("login In OnInit");
        
    }

    login():void{
        this.router.navigate(['/mainpage']);
    }

    goToSignup():void{
        this.router.navigate(['/register']);
    }
}