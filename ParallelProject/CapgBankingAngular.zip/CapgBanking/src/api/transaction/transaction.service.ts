import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { IAccount } from "../../app/account/account";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch'
import 'rxjs/add/operator/do';
import { ITransaction } from "../../app/transaction/transaction";

@Injectable()
export class TransactionService{

    private _transactionsUrl = "./api/transaction/transactions.json";

    constructor(private _http: HttpClient){

    }

    getTransactions(): Observable<ITransaction[]>{
        return this._http.get<ITransaction[]>(this._transactionsUrl)
        .do(data => console.log(data))
        //.do(data => console.log("all: "+JSON.stringify(data)))
        .catch(this.handleError);
    }

    private handleError(err: HttpErrorResponse){
        console.error(err.message);
        return Observable.throw(err.message);
    }
}