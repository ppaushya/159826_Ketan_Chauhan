import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { IAccount } from "../../app/account/account";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch'
import 'rxjs/add/operator/do';

@Injectable()
export class AccountService{

    private _accountsUrl = "./api/account/accounts.json";

    constructor(private _http: HttpClient){

    }

    getAccounts(): Observable<IAccount[]>{
        return this._http.get<IAccount[]>(this._accountsUrl)
        .do(data => console.log(data))
        //.do(data => console.log("all: "+JSON.stringify(data)))
        .catch(this.handleError);
    }

    private handleError(err: HttpErrorResponse){
        console.error(err.message);
        return Observable.throw(err.message);
    }
}