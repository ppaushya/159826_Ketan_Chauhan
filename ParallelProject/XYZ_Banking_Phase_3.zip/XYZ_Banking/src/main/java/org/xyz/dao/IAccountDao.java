package org.xyz.dao;

import java.util.Set;

import org.xyz.model.Account;
import org.xyz.model.Customer;

public interface IAccountDao {
	
	public Set<Account> getAllAccounts();
	
	public Set<Long> getAllAccountIds();
	
	public Account getAccountFromAccountId(long customerId, long accountId);
	
	public void createAccount(Account account);
}
