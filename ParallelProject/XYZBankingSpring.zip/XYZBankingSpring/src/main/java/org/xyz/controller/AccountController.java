package org.xyz.controller;


import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.xyz.model.Account;
import org.xyz.model.RegisterBean;
import org.xyz.service.IAccountService;

@Controller
public class AccountController {

	@Autowired
	private IAccountService accountService;
	
	@PostMapping("/createAccount")
	public String createNewAccount(@Valid @ModelAttribute("accountCreation") Account account,
			HttpSession session, BindingResult result)  {
		
		RegisterBean customer=(RegisterBean) session.getAttribute("customer");
		
		account.setCustomer(customer);
		//System.out.println(account);
		
		if(result.hasErrors())
			return "createAccount";
		if(accountService.createAccount(account))
			{
				return "accountCreated";
			}
		return "redirect:/";
	}
	
	
}
