package org.xyz.service;

import java.util.List;

import org.xyz.model.Account;

public interface IAccountService {

	public boolean createAccount(Account account);
	public List<Account> getAccountsForCustomer(int customerId);
	public List<Account> getAccountsExceptCustomer(int customerId);
	public Account getAccount(long accountNo);
	public double getCurrentBalanceOfAccount(long accountNo);
}
