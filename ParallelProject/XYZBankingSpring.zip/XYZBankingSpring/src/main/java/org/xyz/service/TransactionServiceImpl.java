package org.xyz.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xyz.dao.ITransactionDao;
import org.xyz.model.Account;
import org.xyz.model.Transaction;

@Service("transactionService")
public class TransactionServiceImpl implements ITransactionService {

	@Autowired
	private ITransactionDao transactionDao;
	
	@Autowired
	private IAccountService accountService;
	
	@Override
	public boolean createTransaction(Transaction transaction) {
		if(transaction.getTransaction_type().equals("debit")
				|| transaction.getTransaction_type().equals("fund transfer")) {
			double balance = accountService.getCurrentBalanceOfAccount(transaction.getFrom_account());
			if(balance<transaction.getAmount()) {
				return false;
			}
		}
		return transactionDao.createTransaction(transaction);
	}

	@Override
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate) {
		return transactionDao.getTransactionsForCustomer(customerId, fromDate, toDate);
	}

	/*@Override
	public Map<Account, Double> getCurrentBalance(int customerId) {
		
		return transactionDao.getCurrentBalance(customerId);
	}
*/
	
	

}
