package org.xyz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xyz.dao.AccountDaoImpl;
import org.xyz.dao.IAccountDao;
import org.xyz.dao.ITransactionDao;
import org.xyz.model.Account;
import org.xyz.model.Transaction;

@Service("accountService")
public class AccountServiceImpl implements IAccountService {

	@Autowired
	private IAccountDao accountDao;
	
	@Autowired
	private ITransactionDao transactionDao;
	
	@Override
	public boolean createAccount(Account account) {
		return accountDao.createAccount(account);
	}

	@Override
	public List<Account> getAccountsForCustomer(int customerId) {
		return accountDao.getAccountsForCustomer(customerId);
	}

	@Override
	public List<Account> getAccountsExceptCustomer(int customerId) {
		return accountDao.getAccountsExceptCustomer(customerId);
	}

	@Override
	public Account getAccount(long accountNo) {
		return accountDao.getAccount(accountNo);
	}

	@Override
	public double getCurrentBalanceOfAccount(long accountNo) {
		Account account = getAccount(accountNo);
		List<Transaction> transactions = transactionDao.getTransactionsForAccount(accountNo);
		double balance = account.getOpening_balance();
		for(Transaction transaction:transactions) {
			if(transaction.getTransaction_type().equals("credit")) {
				balance += transaction.getAmount();
			}else if(transaction.getTransaction_type().equals("debit")){
				balance -= transaction.getAmount();
			}else if(transaction.getTransaction_type().equals("fund transfer")){
				if(transaction.getFrom_account()== account.getAccountNumber()) {
					balance -= transaction.getAmount();
				}
				if(transaction.getTo_account() == account.getAccountNumber()){
					balance += transaction.getAmount();
				}
			}
		}
		return balance;
	}
}
