package org.xyz.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.xyz.model.Account;
import org.xyz.model.Transaction;

public interface ITransactionService {

	public boolean createTransaction(Transaction transaction);
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate);
	
}
