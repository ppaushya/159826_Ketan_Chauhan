package org.xyz.model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;


@Entity
@Table(name="accounts")
public class Account {
	

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="customer_id")
	private RegisterBean customer;
	
	@Id
	@Column(name="account_no")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long accountNumber;
	private String account_type;
	private LocalDate opening_date=LocalDate.now();
	@NotNull(message="*Enter opening balance!")
	private double opening_balance;
	private String description;
	
	
	public Account() {
		
	}


	public Account(RegisterBean customer, long accountNumber, String account_type, LocalDate opening_date,
			double opening_balance, String description) {
		super();
		this.customer = customer;
		this.accountNumber = accountNumber;
		this.account_type = account_type;
		this.opening_date = opening_date;
		this.opening_balance = opening_balance;
		this.description = description;
	}


	public RegisterBean getCustomer() {
		return customer;
	}


	public void setCustomer(RegisterBean customer) {
		this.customer = customer;
	}


	public long getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getAccount_type() {
		return account_type;
	}


	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}


	public LocalDate getOpening_date() {
		return opening_date;
	}


	public void setOpening_date(LocalDate opening_date) {
		this.opening_date = opening_date;
	}


	public double getOpening_balance() {
		return opening_balance;
	}


	public void setOpening_balance(double opening_balance) {
		this.opening_balance = opening_balance;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public String toString() {
		return "Account [customer=" + customer + ", accountNumber=" + accountNumber + ", account_type=" + account_type
				+ ", opening_date=" + opening_date + ", opening_balance=" + opening_balance + ", description="
				+ description + "]";
	}


	

}
