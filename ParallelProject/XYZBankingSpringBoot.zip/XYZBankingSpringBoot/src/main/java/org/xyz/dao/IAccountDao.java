package org.xyz.dao;

import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.xyz.model.Account;
import org.xyz.model.CustomerBean;

@Repository("accountDao")
@Transactional
public interface IAccountDao  extends JpaRepository<Account,Long>{

	//public boolean addAccount(Account account);
	//public Set<Account> getAccountsOfCustomer(long customerId);
	//public Set<Account> getAccountsOfOtherCustomers(long excludedCustomerId);
	//public Account getAccountFromAccountId(long accountId);
	
	public List<Account> getAccountByCustomerCustomerId(Long customerId);
	public List<Long> getAccountNumberByCustomerCustomerId(Long customerId);
	public List<Account> getAccountNotByCustomerCustomerId(Long customerId);
}
