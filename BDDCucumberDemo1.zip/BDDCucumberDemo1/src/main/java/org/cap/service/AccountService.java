package org.cap.service;

import org.cap.dao.IAccountDao;
import org.cap.exception.InsufficientBalanceException;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.util.AccountUtil;

public class AccountService implements IAccountService {

	private IAccountDao accountDao;

	public AccountService(IAccountDao accountDao) {
		this.accountDao = accountDao;
	}

	public void setAccountDao(IAccountDao accountDao) {
		this.accountDao = accountDao;
	}

	@Override
	public Account createAccount(Customer customer, double openingBalance) throws InsufficientBalanceException {

		if (customer == null)
			throw new IllegalArgumentException("Sorry! Invalid Customer");
		if (openingBalance < 500)
			throw new InsufficientBalanceException("Insufficient Opening Balance");

		Account account = new Account();
		account.setAccountNumber(AccountUtil.generateAccountno());
		account.setCustomer(customer);
		account.setOpeningBalance(openingBalance);

		if (accountDao.createAccount(account))
			return account;

		return null;
	}

	@Override
	public Account findAccount(int accountNo) {

		return accountDao.findAccount(accountNo);
	}

	@Override
	public Account withdraw(int accountNo, double amount) {
		Account account = accountDao.findAccount(accountNo);

		if (account != null) {
			if (account.getOpeningBalance() > amount) {
				double balance = account.getOpeningBalance() - amount;
				account.setOpeningBalance(balance);
				return account;
			}
		}

		return null;
	}

	@Override
	public Account deposit(int accountNo, double amount) {
		Account account = accountDao.findAccount(accountNo);

		if (account != null) {

			double balance = account.getOpeningBalance() + amount;
			account.setOpeningBalance(balance);
			return account;

		}

		return null;
	}

	@Override
	public Account[] fundTransfer(int fromAccountNo, int toAccountNo, double amount) {
		Account toAccount = accountDao.findAccount(toAccountNo);
		Account fromAccount = accountDao.findAccount(fromAccountNo);

		if (toAccount != null && fromAccount!=null) {

			double toBalance = toAccount.getOpeningBalance() + amount;
			double fromBalance = fromAccount.getOpeningBalance() - amount;
			toAccount.setOpeningBalance(toBalance);
			fromAccount.setOpeningBalance(fromBalance);
			return new Account[]{fromAccount,toAccount};

		}

		return null;
	}
}
