package org.cap.demo;

public class Calculate {

	public int addNumber(int n1,int n2) {
		return n1+n2;
	}
	
	public int multiplyNumber(int n1,int n2) {
		return n1*n2;
	}
	
	public void runLoop() {
		long sum = 0;
		for(int i=0;i<10523662;i++) {
			sum += i;
		}
		System.out.println(sum);
	}
}
