package org.cap.account.util;

public class AccountUtility {

	private static int accountNo = 100;
	public static int generateAccountNo() {
		return ++accountNo;
	}
}
