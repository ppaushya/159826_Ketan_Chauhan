package org.cap.account.model;

public class Customer {

	private int customerId;
	private String name;
	private Address address;
	private Account	account;
	
	public Customer() {
		super();
	}

	public Customer(int customerId, String name, Address address, Account account) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
		this.account = account;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
	
	
}
