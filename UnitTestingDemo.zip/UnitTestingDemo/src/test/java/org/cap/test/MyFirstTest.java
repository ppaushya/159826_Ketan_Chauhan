package org.cap.test;

import static org.junit.Assert.*;

import org.cap.demo.Calculate;
import org.junit.Ignore;
import org.junit.Test;

public class MyFirstTest {

	
	@Ignore
	@Test
	public void test_addNumber_method() {
		//fail("Not yet implemented");
		Calculate calculate = new Calculate();
		
		assertEquals(15, calculate.addNumber(5, 10));
	}

	@Ignore
	@Test
	public void test_multiplyNumber_method() {
		//fail("Not yet implemented");
		Calculate calculate = new Calculate();
		
		assertEquals(15, calculate.multiplyNumber(3, 5));
		assertEquals(100, calculate.multiplyNumber(20, 5));
		assertEquals(16, calculate.multiplyNumber(4, 4));
		assertEquals(150, calculate.multiplyNumber(10, 15));
	}

	@Test(timeout=10)
	public void test_runLoop_method() {
		Calculate calculate = new Calculate();
		calculate.runLoop();
	}

}
