package org.cap.account.test;

import static org.junit.Assert.*;

import org.cap.account.dao.IAccountDao;
import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Account;
import org.cap.account.model.Address;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.cap.account.util.AccountUtility;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class TestAccount {

	@Mock
	private IAccountDao accountDao;
	
	private IAccountService accountService;

	/*@BeforeClass
	public static void setupBefore() {
		System.out.println("@BeforeClass setupBefore");
	}*/
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		accountService = new AccountServiceImpl(accountDao);
	}

	@Ignore
	@Test(expected=IllegalArgumentException.class)
	public void when_createAccount_with_null_customer()
			throws InvalidAmountException {
//		System.out.println("when_createAccount_with_null_customer");
		Customer customer = null;
//		Customer customer = new Customer();
		accountService.createAccount(customer, 3000);
	}
	
	@Ignore
	@Test(expected=InvalidAmountException.class)
	public void when_createAccount_with_low_balance()
			throws InvalidAmountException{
//		System.out.println("when_createAccount_with_low_balance");
		Customer customer = new Customer(AccountUtility.generateAccountNo(), "Cus", new Address(), null);
		accountService.createAccount(customer, 100);
	}

	@Ignore
	@Test
	public void test_add_account() throws InvalidAmountException{
		Customer customer = new Customer(AccountUtility.generateAccountNo(), "Cus", new Address(), null);
		
		Mockito.when(accountDao.addAccount(customer)).thenReturn(true);
		Account account = accountService.createAccount(customer, 3000);
		
		Mockito.verify(accountDao).addAccount(customer);
		assertNotNull(account);
		assertTrue(account.getAccountNo()>0);
		assertEquals(3000, account.getBalance(),0.0);
	}
	
	@Test
	public void test_deposit() throws InvalidAmountException{		
		Account account = new Account(101, "saving", 5000);
		Mockito.when(accountDao.findAccount(101)).thenReturn(account);
		Account account2 = accountService.deposit(account, 500);
		
		Mockito.verify(accountDao).findAccount(101);
		assertEquals(5500, account2.getBalance(),0.0);
	}
	
	@Test
	public void test_withdraw() throws InvalidAmountException{
		Account account = new Account(101, "saving", 5000);
		Mockito.when(accountDao.findAccount(101)).thenReturn(account);
		Account account2 = accountService.withdraw(account, 500);
		
		Mockito.verify(accountDao).findAccount(101);
		assertEquals(4500, account2.getBalance(),0.0);
	}
	
	/*@After
	public void end() {
		System.out.println("end");
	}
	
	@AfterClass
	public static void setupAfter() {
		System.out.println("@AfterClass setupAfter");
	}*/
}
